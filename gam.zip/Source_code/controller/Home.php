<?php
//select * from category where parentid = ".$parentid. ' order by kram desc
// $Categories  = $db->where('status',1)->where('parentid',0)->orderBy('pos','ASC')->orderBy('id')->get(TABLE_CAT);

$GENRE_LIMIT_HOME = 10;
$genres = $db->where('status',1)->where('added_home',1)->orderBy('pos','ASC')->orderBy('id')->get(TABLE_GENRE,$GENRE_LIMIT_HOME,'name,slug');
$stars = $db->where('status',1)->where('added_home',1)->orderBy('pos','ASC')->orderBy('id')->get(TABLE_STAR,$GENRE_LIMIT_HOME,'name,slug');
$directors = $db->where('status',1)->where('added_home',1)->orderBy('pos','ASC')->orderBy('id')->get(TABLE_DIRECTOR,$GENRE_LIMIT_HOME,'name,slug');
//Home Categories
$trendmovies = $db->join(TABLE_CAT.' c', "f.cid=c.id", "INNER")->where('f.status',1)->where('f.trend',1)->orderBy('f.pos','ASC')->orderBy('f.id')->get(TABLE_FILES.' f',6,'f.name,f.thumb,f.slug,f.duration,c.folder,f.release_date');
$newmovies = $db->join(TABLE_CAT.' c', "f.cid=c.id", "INNER")->where('f.status',1)->where('f.newtag',1)->orderBy('f.pos','ASC')->orderBy('f.id')->get(TABLE_FILES.' f',12,'f.name,f.thumb,f.slug,f.duration,c.folder,f.release_date');
$mostviewed = $db->join(TABLE_CAT.' c', "f.cid=c.id", "INNER")->where('f.status',1)->orderBy('f.view','DESC')->orderBy('f.id')->get(TABLE_FILES.' f',8,'f.name,f.thumb,f.slug,f.duration,f.view,c.folder,f.release_date');

//END Homeca
$Route = 'Home';
require_once $Template.'/header.php';
require_once $Template.'/Home.php';
require_once $Template.'/footer.php';