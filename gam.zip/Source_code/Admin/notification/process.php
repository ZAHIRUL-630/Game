<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/init.php';
use Intervention\Image\ImageManagerStatic as Image;
deleteTMPFiles($RootPath.'/upload_file/notification');
if (Input('submit') == "artistlist") {

    if ($q = Input('search'))
        $db->where('name', $q . '%', 'LIKE');
    $data = $db->get('artist', null, 'id,name as text');

    echo json_encode(['results' => $data]);
} else if (Input('submit') == "files") {

    if ($q = Input('search'))
        $db->where('name', $q . '%', 'LIKE');
    $data = $db->get(TABLE_FILES, null, 'id,name as text');

    echo json_encode(['results' => $data]);
} else if (Input('submit') == "catlist") {

    if ($q = Input('search'))
        $db->where('name', $q . '%', 'LIKE');

    $db->where('subcate', 0);
    $data = $db->get(TABLE_CAT, null, 'id,name as text');

    echo json_encode(['results' => $data]);
} else if (Input('submit') == 'send') {

    if(empty(WEBPUSH_REST_KEY) || empty(WEBPUSH_SENDER_ID=="" || WEBPUSH!=1)){
        echo json_encode(['status' => 0, 'message' =>'Please Setup first Notification']);
        exit;
    }
    $errors = array();
    $external_link = Input('external_link');
    $title = Input('title');
    $body = Input('body');
    $artistid = Input('artist');
    $fileid = Input('file');
    $catid = Input('cat');
    $type = Input('notifyfrom');
    $thumb_url =  Input('thumb_url');

    if ($_FILES['thumb']['name']) {
        $thumbname = uniqid('notification_');
        $Imgwh = explode('x', PREVIEW_THUMB);
        $rwh =  $Imgwh[0];
        $path = $RootPath . '/upload_file/notification/' . $thumbname . '.jpg';
        try {
            $Image = Image::make($_FILES['thumb']['tmp_name']);
            $Image->resize($rwh, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $Image->save($path, 100);
            $thumb_url = APP_URL . '/upload_file/notification/' . $thumbname . '.jpg';
        } catch (Intervention\Image\Exception\NotReadableException $e) {
            //     Not Created
        }
    }

    if ($type == 'LINK') {
        if (empty($title))
            array_push($errors, 'Title can not be empty');
        if (empty($external_link))
            array_push($errors, 'URL can not be empty');
        if (empty($body))
            array_push($errors, 'Body can not be empty');
    } else if ($type == 'FILE') {
        $db->join(TABLE_CAT, TABLE_FILES . '.cid=' . TABLE_CAT . '.id', 'INNER');
        $file =  $db->where(TABLE_FILES.'.id', $fileid)->getOne(TABLE_FILES, TABLE_FILES . '.*,' . TABLE_CAT . '.folder,' . TABLE_CAT . '.thumb as category_thumb');
        if(!$file){
            echo json_encode(['status' => 0, 'message' => 'File not found']);

            exit;
        }

        if (empty($title)) {
            $title = $lang['WEBPUSH_HEADING'];
        }

        if (empty($body)) {
            $body = str_replace('{{TITLE}}', $file['name'], $lang['WEBPUSH_BODY']);
        }
        if (empty($external_link)) {
            $external_link = APP_URL . '/' . $file['slug'];
        }
        if(empty($thumb_url)){
            if($file['thumb']){
          $thumb_url = APP_URL.'/'.$file['folder'].PREVIEW_THUMB.'/'.$file['thumb'];  
            }
            else if($file['category_thumb']){
            $thumb_url = APP_URL.'/upload_file/folderthumb/'.PREVIEW_THUMB.'/'.$file['category_thumb'];
            }
        }
    } else if ($type == 'CAT') {
        $cat =  $db->where('id', $catid)->getOne(TABLE_CAT, 'name,thumb,slug');

        if(!$cat){
            echo json_encode(['status' => 0, 'message' => 'Category not found']);

            exit;
        }


        if (empty($title)) {
            $title = $lang['WEBPUSH_HEADING'];
        }

        if (empty($body)) {
            $body = str_replace('{{TITLE}}', $cat['name'], $lang['WEBPUSH_BODY']);
        }
        if (empty($external_link)) {
            $external_link = APP_URL . '/category/' . $cat['slug'];
        }

        if(empty($thumb_url)){
            if($cat['thumb']){
          $thumb_url = APP_URL.'/upload_file/folderthumb/'.PREVIEW_THUMB.'/'.$cat['thumb'];  
            }
        }
    }


if(count($errors)==0){
$SendPush = SendWebPush($title, $body, $thumb_url, $external_link);
if($SendPush == true)
echo json_encode(['status' => 1, 'message' =>'Successfuly Notification Send']);
else {
echo json_encode(['status' => 0, 'message' =>'Unsuccessfuly']);  
}
}
else {
echo json_encode(['status' => 0, 'message' =>$errors[0]]);
}
}
