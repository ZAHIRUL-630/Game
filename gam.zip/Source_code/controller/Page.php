<?php
$page = $output[1];
$title = ucwords($page);
if(file_exists($Template.'/pages/'.$page.'.php')){
    require_once $Template.'/header.php';
    require_once $Template.'/pages/'.$page.'.php';
    require_once $Template.'/footer.php';
} else {
    if (ERROR_PAGE == true) {
        require __DIR__ . '/ErrorPage.php';
    } else {
        Redirect(APP_URL);
    }
}