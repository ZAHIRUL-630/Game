<?php
/**
 * @author devops <devt.santu@gmail.com>
 */
require_once __DIR__ . '/../header.php';
$profile = $db->where('id', $_SESSION['id'])->getOne(TABLE_ADMIN, 'username,email');
?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="d-flex justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Profile</h6>
            </div>
        </div>
        <div class="card-body">
            <form id="profileform">
                <div class="col-md-8">
                    <div class="form-row">
                        <div class="col-md-12">
                            <div class="input-group m-2">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Username</span>
                                </div>
                                <input type="text" name="username" id="username" class="form-control" value="<?php echo $profile['username']; ?>" required="1" placeholder="Enter Your Username" />
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="input-group m-2">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Email</span>
                                </div>
                                <input type="email" name="email" id="user_email" class="form-control" value="<?php echo $profile['email']; ?>" required="1" placeholder="Enter Your Email" />
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="input-group m-2">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Old Password</span>
                                </div>
                                <input type="text" name="old_pass" id="old_pass" class="form-control" required="1" placeholder="Enter Old Password" />
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="input-group m-2">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">New Password</span>
                                </div>
                                <input type="text" name="new_pass" id="new_pass" class="form-control" placeholder="New Password" />
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="input-group m-2">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Confirm Password</span>
                                </div>
                                <input type="text" name="confirm_pass" id="confirm_pass" class="form-control" placeholder="New Password" />
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="submit" value="change">
                    <div class="row justify-content-end"><button type="submit" class="btn btn-primary" value="change" id="submitbutton">Submit</button></div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/../footer.php';
?>