<?php require_once __DIR__ . '/../header.php'; ?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">

            <div class="d-flex justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Updates:</h6>
            </div>
        </div>
        <div class="cms-update-system">
            <div class="container">
                <div class="card">
                    <h2>Current Version</h2>
                    <p id="current-version">Version 1.0.0</p>
                    <i class="icon">&#128640;</i>
                </div>
                <div class="card">
                    <h2>Update Status</h2>
                    <p id="update-status">Checking for updates...</p>
                    <div class="status-bar">
                        <div class="status-bar-fill" id="status-bar-fill"></div>
                    </div>
                </div>
                <div class="card">
                    <h2>Update Log</h2>
                    <textarea id="update-log" rows="10" readonly>Fetching update log...</textarea>
                </div>
                <div class="card">
                    <h2>Update Now</h2>
                    <div class="btn-container">
                        <button id="update-btn" disabled>Update Now</button>
                    </div>
                </div>
                <div class="version-history">
                    <h2>Version History</h2>
                    <div class="version-item">
                        <h3>Version 0.9.5</h3>
                        <p class="date">Released: 2022-12-15</p>
                        <p>Initial beta release with basic CMS features like content management and user authentication.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
require_once __DIR__ . '/../footer.php';
?>