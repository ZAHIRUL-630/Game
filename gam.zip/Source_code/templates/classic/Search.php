<main class="container bg-light shadow-sm rounded-bottom border-top pb-2">
   <div class="row">
      <div class="col-12 col-lg-8">
         <?php echo $breadhtml; ?>
         <h1 class="px-2 pt-2 mb-1 text-dark text-truncate fs-5 fw-normal text-uppercase"><?php echo $searchq ? $searchq . ' - Search Result' : 'Search Result'; ?></h1>
         <h2 class="pb-2 ps-2 mb-3 text-truncate fs-6 fw-normal border-bottom"><i class="fa fa-search" aria-hidden="true"></i> <?php echo $searchq; ?></h2>
         <?php if (!$type) : ?>
         <div class="card card-body mb-2">
            <form class="d-flex" action="<?php echo APP_URL . '/search/list'; ?>" method="GET">
               <div class="input-group me-2">
                  <input class="form-control" type="text" name="q" placeholder="Search" value="<?php echo isset($searchq) ? $searchq : ''; ?>" aria-label="Search">
                  <div class="input-group-append">
                     <select name="search" aria-label="SearchType" class="form-control">
                        <option value="movie">Movie</option>
                        <option value="star">Star</option>
                        <option value="director">Director</option>
                     </select>
                  </div>
               </div>
               <button class="btn btn-danger" type="submit">Search</button>
            </form>
         </div>
         <?php endif; ?>

         <div class="row row-cols-3 row-cols-sm-4 row-cols-md-6 bg-light g-1 g-sm-2 mb-3">
            <?php
            require_once __DIR__ . '/_files_list.php';
            $goroute = ($type == 'star') ? 'stars' : 'directors';
            require_once __DIR__ . '/_collection_list.php';
            ?>
         </div>
         <?php
         if ($type) {
            echo skyPageNavigate($totalPage, $page, $pagelimit, $pageLink);
         }
         ?>

      </div>
      <div class="col-12 col-lg-4">
         <?php include(getAds($AdsPath . '/sidebar_before')); ?>
         <h3><i class="fa fa-random" aria-hidden="true"></i> You May Also Like</h3>
         <ul class="list-group sb-list">
            <?php if ($type) {
               $listitems = $ReletedAlso;
               $list_href = $type;
               require_once __DIR__ . '/_list_itemExtra.php';
               $listitems = $YouMayMovies;
               require_once __DIR__ . '/_list_item.php';
               unset($ReletedAlso);
            } ?>
         </ul>
      </div>
   </div>
</main>