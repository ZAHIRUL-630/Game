<?php
if ($listitems) {
    $cnt = 0;
    $thumbsize = explode('x', LIST_THUMB);
    foreach ($listitems as $item) {
        $cnt++;
        if ($item['thumb']) {
            $thumb = APP_URL . '/' . $item['folder'] . LIST_THUMB . '/' . $item['thumb'];
        } else {
            $thumb = APP_URL . '/assets/images/movie.svg';
        }
        echo '<li class="list-group-item">
    <a href="' . APP_URL . '/movie/' . $item['slug'] . $endRoute . '" class="d-flex list-m">
        <img src="' . APP_URL.'/assets/images/movie.svg" data-src="'.$thumb.'" class="lazy float-start rounded" alt="' . $item['name'] . '" width="' . $thumbsize[0] . '" height="' . $thumbsize[1] . '">
        <div class="ms-2 text-truncate align-self-center w-100">
            <h4>' . $item['name'] . ' <span>(' . date('Y', strtotime($item['release_date'])) . ')</span></h4>
            <p><i class="fa fa-clock-o" aria-hidden="true"></i> ' . $item['duration'] . ' Min</p>
            <p><i class="fa fa-eye" aria-hidden="true"></i> ' . $item['view'] . '+</p>
        </div>
    </a>
</li>';
        if($cnt % ADVT_EACH == 0){
            include(getAds($AdsPath . '/between_listitem'));
            }
    }
    unset($listitems);
    unset($thumbsize);
}
