<?php
/**
 * @author devops <devt.santu@gmail.com>
 */
header("Access-Control-Allow-Origin: *");
header("Content-Type: text/event-stream");
header("Cache-Control: no-cache");
header("Connection: keep-alive");
ob_implicit_flush(true);
ob_end_flush();


$updateZip = "../../update.zip";
$extractPath = "../../";
$versionFile = "../../config/version";

$clientDomain = $_SERVER['HTTP_HOST']; 

$getTokenUrl = str_rot13("uggcf://vzqribcf.va/ncv/hcqngrf/trgGbxra.cuc?cvq=1&qbznva=") . urlencode($clientDomain);
$tokenResponse = file_get_contents($getTokenUrl);

if (!$tokenResponse) {
    echo json_encode(["success" => false, "message" => "❌ Error fetching secure token!"]);
    exit;
}

$tokenData = json_decode($tokenResponse, true);
if (!$tokenData || !$tokenData['success']) {
    echo json_encode(["success" => false, "message" => "❌ Failed to obtain secure token! " . ($tokenData['message'] ?? "Unknown error")]);
    exit;
}

function sendMessage($message, $delay = 1) {
    sleep($delay);
    echo "data: " . json_encode(["message" => $message]) . "\n\n";
    if (ob_get_level() > 0) {
        ob_flush();
    }
    flush();
}

sendMessage("🔄 Checking for updates...", 1);

$token = $tokenData['token'];
$downloadUrl = str_rot13("uggcf://vzqribcf.va/ncv/hcqngrf/qbjaybnq.cuc?cvq=1&gbxra=") . urlencode($token);

sendMessage("🔽 Downloading update file...", 2);

$downloaded = file_put_contents($updateZip, file_get_contents($downloadUrl));

if ($downloaded === false) {
    sendMessage("❌ Failed to download update file.");
    exit;
}

sendMessage("✅ Update file downloaded successfully!", 2);

$zip = new ZipArchive;
if ($zip->open($updateZip) === TRUE) {
    sendMessage("📂 Extracting files...", 3);
    $zip->extractTo($extractPath);
    $zip->close();
    sendMessage("✅ Files extracted successfully!", 4);

    if (file_exists($updateZip)) {
        unlink($updateZip);
        sendMessage("🗑️ Cleaning up temporary files...", 5);
        sendMessage("✅ Temp file removed successfully!", 6);
    }

    $getVersionUrl = str_rot13("uggcf://vzqribcf.va/ncv/hcqngrf/trgIrefvba.cuc?cvq=1");
    $versionResponse = file_get_contents($getVersionUrl);
    if (!$versionResponse) {
        sendMessage("⚠️ Failed to fetch latest version info.", 7);
        exit;
    }

    $versionData = json_decode($versionResponse, true);
    if ($versionData && isset($versionData['latest_version']['version']) && isset($versionData['latest_version']['date']) && isset($versionData['latest_version']['changelog'])) {
        $latestVersion = trim($versionData['latest_version']['version']);
        $releaseDate = trim($versionData['latest_version']['date']);
        $changelog = trim($versionData['latest_version']['changelog']);

        $newVersionEntry = "$latestVersion | $releaseDate | $changelog\n";
        sendMessage("📝 Updating version info...", 8);

        if (file_exists($versionFile)) {
            $existingContent = file_get_contents($versionFile);
            file_put_contents($versionFile, $newVersionEntry . $existingContent);
        } else {
            file_put_contents($versionFile, $newVersionEntry);
        }
        sendMessage("✅ Updated version with version $latestVersion", 9);
    } else {
        sendMessage("⚠️ Failed to fetch latest version info.", 10);
    }

    sendMessage("🚀 Update successfully applied! Reloading in 3sec...", 11);
    sendMessage("end");
    
    exit;
} else {
    sendMessage("❌ Failed to extract update file.");
    exit;
}
?>
