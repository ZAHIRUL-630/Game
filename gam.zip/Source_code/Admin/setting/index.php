<?php

/**
 * @author devops <devt.santu@gmail.com>
 */
require_once '../header.php';
require_once $RootPath . '/config/language.php';
?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="d-flex justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Settings</h6>
            </div>
        </div>
        <div class="card-body">
            <form id="settingform" action="process.php" method="POST" enctype="multipart/form-data">
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="app_name">App Name:</label>
                        <input type="text" name="app_name" value="<?php echo APP_NAME; ?>" class="form-control">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="thumb">Logo: (1:1)</label>
                        <div class="custom-file">
                            <label for="thumb" class="custom-file-label">Choose File</label>
                            <input type="file" name="logo" class="custom-file-input" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="app_name">Template:</label>
                        <select name="tplname" id="tplname" class="form-control">
                            <?php
                            $dirlist  = scandir($RootPath . '/templates');
                            foreach ($dirlist as $dir) {
                                if (!(pathinfo($dir, PATHINFO_EXTENSION)) && !in_array($dir, ['.', '..', 'ads', 'pages', 'widget', 'amp'])) {
                                    if ($dir == TEMPLATE) {
                                        echo '<option value="' . $dir . '" selected>' . $dir . '</option>';
                                    } else {
                                        echo '<option value="' . $dir . '">' . $dir . '</option>';
                                    }
                                }
                            } ?>
                        </select>
                    </div>
                    <div class="form-group col-12">
                        <label for="app_name">SITE HTTPS:</label>
                        <input type="checkbox" class="form-control align-self-center" data-toggle="switch" name="site_https" value="1" <?php echo (APP_HTTPS == 1) ? ' checked' : '' ?> />
                        <label for="app_name">OG IMAGE (<small>If turn off All Page set default ogimage</small>):</label>
                        <input type="checkbox" class="form-control align-self-center" data-toggle="switch" name="thumbog" value="1" <?php echo (THUMB_OGIMAGE == 1) ? ' checked' : '' ?> />
                        <label for="app_name">Web Push Notification:</label>
                        <input type="checkbox" class="form-control align-self-center" data-toggle="switch" name="webpush" value="1" <?php echo (WEBPUSH == 1) ? ' checked' : '' ?> />
                    </div>
                    <div class="form-group col-12">
                        <label>Site Title:</label>
                        <input type="text" name="home_title" value="<?php echo $title; ?>" class="form-control">
                    </div>
                    <div class="form-group col-12">
                        <label>Site Description:</label>
                        <input type="text" name="home_des" value="<?php echo $metadescription; ?>" class="form-control">
                    </div>
                    <div class="form-group col-12">
                        <label>Site Keywords:</label>
                        <input type="text" name="home_keywords" value="<?php echo $metakeywords; ?>" class="form-control">
                    </div>
                    <div class="form-group col-md-2">
                        <label>Files Per Page:</label>
                        <input type="text" name="files_per_page" value="<?php echo FILES_PER_PAGE; ?>" class="form-control">
                    </div>
                    <div class="form-group col-md-2">
                        <label>Category Per Page:</label>
                        <input type="text" name="cat_per_page" value="<?php echo CATEGORY_PER_PAGE; ?>" class="form-control">
                    </div>
                    <div class="form-group col-md-2">
                        <label>Releted Files Limit:</label>
                        <input type="text" name="releted_limit" value="<?php echo RELETED_FILES_LIMIT; ?>" class="form-control">
                    </div>
                    <div class="form-group col-md-3">
                        <label>Thumb Sizes:</label>
                        <input type="text" name="cat_icon_sizes" value="<?php echo CATICON_SIZES; ?>" class="form-control">
                    </div>

                    <div class="form-group col-md-3">
                        <label for="thumb">Thumbnail Watermark:</label>
                        <div class="custom-file">
                            <label for="thumb" class="custom-file-label">Choose File</label>
                            <input type="file" name="thumb_watermark" class="custom-file-input" />
                        </div>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="thumb">META OG IMAGE:</label>
                        <div class="input-group">
                            <input type="text" name="ogimageurl" class="form-control" value="<?php echo $metaogimage; ?>">
                            <div class="input-group-append">
                                <span class="input-group-text">OR</span>
                                <div class="custom-file">
                                    <label for="thumb" class="custom-file-label">Choose File</label>
                                    <input type="file" name="ogimage" class="custom-file-input" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group col-md-3">
                        <label>Default Ads Network:</label>
                        <select name="ads_network" class="form-control">
                            <?php
                            $Size = explode(',', ADS_NETWORK);
                            foreach ($Size as $s) {
                                if ($s == DEFAULT_ADS) {
                                    echo '<option value="' . $s . '" selected>' . $s . '</option>';
                                } else {
                                    echo '<option value="' . $s . '">' . $s . '</option>';
                                }
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-group col-3">
                        <label>Thumbnail Format:</label>
                        <select name="thumbnail_format" class="form-control">
                            <?php
                            $Size = ['png', 'jpg', 'webp'];
                            foreach ($Size as $s) {
                                if ($s == THUMB_FORMAT) {
                                    echo '<option value="' . $s . '" selected>' . $s . '</option>';
                                } else {
                                    echo '<option value="' . $s . '">' . $s . '</option>';
                                }
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-group col-3">
                        <label>Thumbnail Quality:</label>
                        <input type="text" name="thumb_quality" value="<?php echo THUMB_QUALITY; ?>" class="form-control">
                    </div>

                    <div class="form-group col-3">
                        <label>ADVT EACH LIST:</label>
                        <input type="text" name="advt_each" value="<?php echo ADVT_EACH; ?>" class="form-control">
                    </div>

                    <div class="form-group col-6">
                        <label>WEPUSH SENDER ID:</label>
                        <input type="text" name="onesignalid" value="<?php echo WEBPUSH_SENDER_ID; ?>" class="form-control">
                    </div>
                    <div class="form-group col-6">
                        <label>WEBPUSH REST API Key:</label>
                        <input type="text" name="onesignalrest" value="<?php echo WEBPUSH_REST_KEY; ?>" class="form-control">
                    </div>
                    <div class="col-12 alert alert-warning" role="alert">
                        Note: If You Want To Change PAGE META TITLE, PAGE META DESCRIPTION, PAGE META KEYWORDS <br>
                        Edit : <?php echo realpath($RootPath . '/config/language.php'); ?><br>
                        Free Support: devt.santu@gmail.com
                    </div>
                </div>
                <button type="submit" id="submit" class="btn btn-success">Submit</button>
            </form>
        </div>

    </div>
</div>

<?php
require_once '../footer.php';
?>