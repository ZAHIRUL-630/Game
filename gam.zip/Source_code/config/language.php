<?php
//FILE DETAIL PAGE
$lang['FILE_TITLE'] = '{{FILENAME}} ({{RELEASE_DATE}}) Movie Download';
$lang['FILE_AUTO_TAG'] = '{{FILENAME}} ({{RELEASE_DATE}}) Movie Download, {{FILENAME}} Releasing at {{RELEASE_DATE}} Download and Watch Online High Quality 480p, 720p, 1080p Full HD Movie Download, filmywap 2021, filmyzilla, filmyzilla';
$lang['FILE_META_DESCRIPTION'] ='{{FILENAME}} ({{RELEASE_DATE}}) Movie from {{CATEGORY_NAME}} Releasing at {{RELEASE_DATE}} Full Movie Download and Watch Online Free';
$lang['FILE_META_KEYWORDS'] ='{{FILENAME}} {{RELEASE_DATE}}, {{CATEGORY_NAME}}, Full Movie Download, Watch Online Free';

//FILELIST DETAIL PAGE
$lang['FILELIST_TITLE'] = '{{CATEGORY_NAME}} Download';
$lang['FILELIST_AUTO_TAG'] = '{{CATEGORY_NAME}} Download, {{CATEGORY_NAME}} High Quality 360p 480p 720p Watch Online Free and Download filmywap 2021, filmyzilla, filmyzilla';
$lang['FILELIST_META_DESCRIPTION'] ='{{CATEGORY_NAME}} Download In 360p 480p 720p HD Free Download free filmywap 2021, filmyzilla, filmyzilla';
$lang['FILELIST_META_KEYWORDS'] ='{{CATEGORY_NAME}}, free download, {{CATEGORY_NAME}} all Movie, filmywap 2021, filmyzilla, filmyzilla';

//CATLIST DETAIL PAGE
$lang['CATLIST_TITLE'] = '{{CATEGORY_NAME}}';
$lang['CATLIST_AUTO_TAG'] = '{{CATEGORY_NAME}} All Movie List Download and Watch Online Movie Free, {{CATEGORY_NAME}} 720p 480p 360p with High Speed Download Server';
$lang['CATLIST_META_DESCRIPTION'] ='{{CATEGORY_NAME}} Watch Free and download 360p 720p 480p Full HD High Speed Server, filmywap 2021, filmyzilla, filmyzilla';
$lang['CATLIST_META_KEYWORDS'] ='{{CATEGORY_NAME}} download, watch free online, filmywap 2021, filmyzilla, filmyzilla';


$lang['STAR_TITLE'] = '{{STAR_NAME}} All Movies Download';
$lang['STAR_AUTO_TAG'] = '{{STAR_NAME}} All Movies download in 360p 480p 720p Full HD with High Speed Server {{STAR_NAME}} Watch Online Movie free';
$lang['STAR_META_DESCRIPTION'] ='{{STAR_NAME}} all movie download free, {{STAR_NAME}} Movie in Full HD 720p 480p 360p Download & Watch Free';
$lang['STAR_META_KEYWORDS'] ='{{STAR_NAME}} all songs, album, movie download';

$lang['DIRECTOR_TITLE'] = '{{DIRECTOR_NAME}} All Movies Download';
$lang['DIRECTOR_AUTO_TAG'] = '{{DIRECTOR_NAME}} All Movies download in 360p 480p 720p Full HD with High Speed Server {{DIRECTOR_NAME}}  Watch Online Movies free';
$lang['DIRECTOR_META_DESCRIPTION'] ='{{DIRECTOR_NAME}} all movie download free, {{DIRECTOR_NAME}} Movie in Full HD 720p 480p 360p Download & Watch Free';
$lang['DIRECTOR_META_KEYWORDS'] ='{{DIRECTOR_NAME}} all songs, album, movie download';


$lang['GENRE_TITLE'] = '{{GENRE_NAME}} All Movies Download';
$lang['GENRE_AUTO_TAG'] = '{{GENRE_NAME}} All Movies download in 360p 480p 720p Full HD with High Speed Server {{GENRE_NAME}}  Watch Online Movies free';
$lang['GENRE_META_DESCRIPTION'] ='{{GENRE_NAME}} all movie download free, {{GENRE_NAME}} Movie in Full HD 720p 480p 360p Download & Watch Free';
$lang['GENRE_META_KEYWORDS'] ='{{GENRE_NAME}} all songs, album, movie download';


$lang['WEBPUSH_HEADING'] = 'Alert';
$lang['WEBPUSH_BODY'] = '{{TITLE}}';