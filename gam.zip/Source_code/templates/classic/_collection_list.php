<?php
if($collection){
$cnt = 0;
if($goroute=='star')
$thumbdir = 'starthumb';
elseif($goroute=='director'){
  $thumbdir = 'directorthumb';
} else {
  $thumbdir = 'genrethumb';
}
$thumbsize = explode('x',CARD_THUMB);
foreach($collection as $collect){
  $cnt++;
  if($collect['thumb']){
    $thumb = APP_URL.'/upload_file/'.$thumbdir.'/'.CARD_THUMB.'/'.$collect['thumb'];
   } else{
     $thumb = APP_URL.'/assets/images/thumbnail.svg';
   }
   echo '<div class="col">
   <a data-bs-toggle="tooltip" title="'.$collect['name'].'" href="'.APP_URL.'/'.$goroute.'/'.$collect['slug'].$endRoute.'" class="card movie" width="'.$thumbsize[0].'" height="'.$thumbsize[1].'">
     <img src="' . APP_URL.'/assets/images/thumbnail.svg" data-src="'.$thumb.'" class="lazy card-img-top" alt="'.$collect['name'].'">
     <div class="movie-body">
       <h4>'.$collect['name'].'</h4>
     </div>
   </a>
 </div>';
if($cnt % ADVT_EACH == 0){
include(getAds($AdsPath . '/between_catlist'));
}
}
unset($collection);
unset($thumbsize);
unset($thumbdir);
}
