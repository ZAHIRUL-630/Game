<?php
/**
 * @author devops <devt.santu@gmail.com>
 */
require_once '../config/init.php';
unset($_SESSION['id']);
unset($_SESSION['username']);
session_destroy();
if (!isset($_SESSION['id']) && !isset($_SESSION['username'])) {
    header('Location: ' . APP_URL . '/' . ADMIN_DIR . '/user/login.php');
    exit;
}
?>