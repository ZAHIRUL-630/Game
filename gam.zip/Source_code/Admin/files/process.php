<?php

/**
 * @author devops <devt.santu@gmail.com>
 */
header('Content-Type: application/json; charset=utf-8');
require_once '../config/init.php';
$currentAction = Input('submit');
if ($currentAction == 'list') {
	$db->join(TABLE_CAT, '' . TABLE_CAT . '.id=' . TABLE_FILES . '.cid', "INNER");
	$searchValue = dtsValue();
	if ($searchValue) {
		$db->where(TABLE_FILES . '.name', '%' . $searchValue . '%', 'LIKE');
	}
	if (InputArray('order')) {
		$column = dtOrderby();
		if ($column == 2)
			$db->orderBy(TABLE_FILES . '.name', dtOrderby(false));
		else if ($column == 8)
			$db->orderBy(TABLE_FILES . '.release_date', dtOrderby(false));
		else if ($column == 11)
			$db->orderBy(TABLE_FILES . '.view', dtOrderby(false));
		else if ($column == 12)
			$db->orderBy(TABLE_FILES . '.pos', dtOrderby(false));
		else {
			$db->orderBy(TABLE_FILES . '.id', dtOrderby(false));
		}
	} else {
		$db->orderBy(TABLE_FILES . '.pos', 'ASC');
		$db->orderBy(TABLE_FILES . '.id');
	}
	if (Input('parentid')) {
		$db->where(TABLE_FILES . '.cid', Input('parentid'));
	}
	$selectData = TABLE_FILES . '.*,' . TABLE_CAT . '.name as category_name,' . TABLE_CAT . '.folder';

	if (Input('length') != -1) {
		$files = $db->withTotalCount()->get(TABLE_FILES, array(dtlimit(), dtlimit(false)), $selectData);
	} else {
		$files = $db->withTotalCount()->get(TABLE_FILES, null, $selectData);
	}
	$numRows = $db->totalCount;
	$data = array();
	$size = explode(',', FILE_THUMB_SIZES);

	foreach ($files as $file) {
		$row = array();
		$action = '';
		if ($file['thumb'] != "") {
			$thumb = '<img class="border border-dark" src="../../' . $file['folder'] . $size[0] . '/' . $file['thumb'] . '" alt="Icon" width="60" height="60">';
		} else {
			$thumb = '';
		}
		$action .= '<a href="edit.php?id=' . $file['id'] . '" class="btn btn-success btn-sm">Edit</a><button type="button" name="delete" id="' . $file["id"] . '" class="delete btn btn-danger btn-sm m-2">Delete</button>';
		$row[] = $file['id'];
		$row[] = $thumb;
		$row[] = $file['name'];
		$row[] = '<a href="?cid=' . $file['cid'] . '">' . $file['category_name'] . '</a>';
		$row[] = $file['duration'];
		$row[] = $file['director'];
		$row[] = $file['star'];
		$row[] = $file['genre'];
		$row[] = date('Y', strtotime($file['release_date']));
		$row[] = $file['rating'];
		$row[] = $file['total_rate'];
		$row[] = $file['view'];
		$row[] = $file['pos'];
		$row[] = ($file['status'] == true) ? '<span id="' . $file['id'] . '" class="status btn btn-success btn btn-sm m-2">Active</span>' : '<span id="' . $file['id'] . '" class="status btn btn-warning btn-sm m-2">Block</span>';
		$row[] = $action;
		$data[] = $row;
	}
	$output = array(
		"draw"				=>	intval(Input('draw')),
		"recordsTotal"  	=>  $numRows,
		"recordsFiltered" 	=> 	$numRows,
		"data"    			=>   $data
	);
	echo json_encode($output);
} elseif ($currentAction == "statusUpdater") {

	$id = Input('id');
	$status = $db->where('id', $id)->getValue(TABLE_FILES, 'status');

	if ($status == 1) {
		$data = ['status' => 0];
	} else {
		$data = ['status' => 1];
	}
	$db->where('id', $id)->update(TABLE_FILES, $data);
	echo json_encode([
		'status' => 1,
		'message' => 'Status Updated'

	]);
} elseif ($currentAction == "delete") {

	$id = Input('id');
	$file = $db->where('id', $id)->getOne(TABLE_FILES);
	$category = $db->where('id', $file['cid'])->getOne(TABLE_CAT);

	if (!$category && !$file) {
		echo json_encode([
			'status' => 2,
			'message' => 'Delete Failed'

		]);
		exit;
	}

	$parentids = array_filter(explode('/', $category['folder']));
	array_shift($parentids);
	if ($parentids) {
		$db->where('id', $parentids, 'IN')->update(TABLE_CAT, ['totalitem' => $db->dec(1)]);
	}
	$thumbname = $file['thumb'];
	if ($thumbname) {
		$appsizes = explode(',', FILE_THUMB_SIZES);
		foreach ($appsizes as $wh) {
			$Imgwh = explode('x', $wh);
			$ImgDir =  $RootPath . '/' . $category['folder'] . $wh;
			if (file_exists($ImgDir . '/' . $thumbname))
				unlink($ImgDir . '/' . $thumbname);
		}
	}
	deleteDownLinks($id);
	$db->where('id', $id)->delete(TABLE_FILES);
	echo json_encode([
		'status' => 1,
		'message' => 'Deleted Successfuly'

	]);
} else if ($currentAction == "removethumb") {
	if ($id = Input('id')) {
		$file =  $db->where('id', $id)->getOne(TABLE_FILES);
		$category = $db->where('id', $file['cid'])->getOne(TABLE_CAT);

		$thumbname = $file['thumb'];
		if ($thumbname) {
			$appsizes = explode(',', FILE_THUMB_SIZES);
			foreach ($appsizes as $wh) {
				$Imgwh = explode('x', $wh);
				$ImgDir =  $RootPath . '/' . $category['folder'] . $wh;
				if (file_exists($ImgDir . '/' . $thumbname))
					unlink($ImgDir . '/' . $thumbname);
			}
		}
		$db->where('id', $id)->update(TABLE_FILES, ['thumb' => '']);
	}
	echo json_encode([
		'status' => 1,
		'message' => 'Thumbnail Removed'

	]);
} elseif ($currentAction == "slugcheck") {

	$id = Input('id');
	$slug = Input('slug');
	$slug = genSlug($slug, $id);

	echo json_encode([
		'status' => 1,
		'slug' => $slug,
	]);
} else if ($currentAction == 'tagsdirector') {
	$tag = Input('term');

	if ($tag) {
		$db->where('name', '%' . $tag . '%', 'LIKE');
	}
	$data = $db->get(TABLE_DIRECTOR, null, 'name');
	$tags = array();
	foreach ($data as $d) {
		array_push($tags, $d['name']);
	}
	echo json_encode($tags);
} else if ($currentAction == 'tagsstar') {
	$tag = Input('term');

	if ($tag) {
		$db->where('name', '%' . $tag . '%', 'LIKE');
	}
	$data = $db->get(TABLE_STAR, null, 'name');
	$tags = array();
	foreach ($data as $d) {
		array_push($tags, $d['name']);
	}
	echo json_encode($tags);
} elseif ($currentAction == "genrelist") {

	if ($q = Input('search'))
		$db->where('name', $q . '%', 'LIKE');

	$data = $db->get(TABLE_GENRE, null, 'name as id,name as text');

	echo json_encode(['results' => $data]);
	exit;
} else if ($currentAction == "multipledelete") {
	$ids = InputArray('ids');
	$cnt = 0;
	if ($ids) {
		foreach ($ids as $id) {
			if ($id) {
				$file = $db->where('id', $id)->getOne(TABLE_FILES);
				if (!$file) {
					continue;
				}
				$category = $db->where('id', $file['cid'])->getOne(TABLE_CAT);
				if (!$category) {
					continue;
				}
				$parentids = array_filter(explode('/', $category['folder']));
				array_shift($parentids);
				if ($parentids) {
					$db->where('id', $parentids, 'IN')->update(TABLE_CAT, ['totalitem' => $db->dec(1)]);
				}
				$thumbname = $file['thumb'];
				if ($thumbname) {
					$appsizes = explode(',', FILE_THUMB_SIZES);
					foreach ($appsizes as $wh) {
						$Imgwh = explode('x', $wh);
						$ImgDir =  $RootPath . '/' . $category['folder'] . $wh;
						if (file_exists($ImgDir . '/' . $thumbname))
							unlink($ImgDir . '/' . $thumbname);
					}
				}

				deleteDownLinks($id);
				if ($db->where('id', $id)->delete(TABLE_FILES)) {
					$cnt++;
				}
			}
		}

		echo json_encode([
			'status' => 1,
			'message' => 'Total ' . $cnt . ' Deleted Successfuly'

		]);
		exit;
	}

	echo json_encode([
		'status' => 0,
		'message' => 'No Item Selected'

	]);
} else if ($currentAction == "MoveFiles") {
	$ids = InputArray('ids');
	$targetid = Input('targetId');
	if (!$ids || !$targetid) {
		echo json_encode([
			'status' => 0,
			'message' => 'No Item Selected or Target Category Id Missing'

		]);
		exit;
	}
	$catinfo = $db->where('id', $targetid)->getOne(TABLE_CAT);

	if (!$catinfo) {
		echo json_encode([
			'status' => 0,
			'message' => 'Target Category Not Found'

		]);
		exit;
	}

	if ($catinfo['subcate'] != 0) {
		echo json_encode([
			'status' => 0,
			'message' => 'Target Category are not a Child'

		]);
		exit;
	}

	$cnt = 0;
	foreach ($ids as $id) {
		if ($id) {
			$file = $db->where('id', $id)->getOne(TABLE_FILES);
			if (!$file) {
				continue;
			}
			$category = $db->where('id', $file['cid'])->getOne(TABLE_CAT);
			if (!$category) {
				continue;
			}

			if ($targetid == $category['id']) {
				continue;
			}

			$parentids = array_filter(explode('/', $category['folder']));
			array_shift($parentids);
			if ($parentids) {
				$db->where('id', $parentids, 'IN')->update(TABLE_CAT, ['totalitem' => $db->dec(1)]);
			}
			$thumbname = $file['thumb'];
			if ($thumbname) {
				$appsizes = explode(',', FILE_THUMB_SIZES);
				foreach ($appsizes as $wh) {
					$Imgwh = explode('x', $wh);
					$ImgDir =  $RootPath . '/' . $category['folder'] . $wh;
					$ThumbSavePath = $RootPath . '/' . $catinfo['folder'] . $wh;
					if (!is_dir($ThumbSavePath)) {
						mkdir($ThumbSavePath);
					}
					if (file_exists($ImgDir . '/' . $thumbname)) {
						rename($ImgDir . '/' . $thumbname, $ThumbSavePath . '/' . $thumbname);
					}
				}
			}
			$parentidsinc = array_filter(explode('/', $catinfo['folder']));
			array_shift($parentidsinc);
			if ($parentidsinc) {
				$db->where('id', $parentidsinc, 'IN')->update(TABLE_CAT, ['totalitem' => $db->inc(1)]);
			}
			if ($db->where('id', $id)->update(TABLE_FILES, ['cid' => $targetid]))
				$cnt++;
		}
	}

	echo json_encode([
		'status' => 1,
		'message' => 'Total ' . $cnt . ' Moved Successfuly'

	]);
	exit;
} else if ($currentAction == "linkdelete") {
	$id = Input("id");

	if ($id) {

		if ($db->where('id', $id)->delete(TABLE_LINKS)) {
			echo json_encode([
				'status' => 1,
				'message' => 'Deleted'

			]);
			exit;
		}
	}



	echo json_encode([
		'status' => 0,
		'message' => 'Delete Failed'

	]);
	exit;
} elseif ($currentAction == "imdbsearch") {
	function getImdbid($url)
	{
		$re = '/title\/tt([0-9+]+)\//m';
		if (@preg_match($re, $url, $data)) {
			return $data[1];
		}
		return false;
	}
	function checkExistsMovie($id)
	{
		global $db;
		return $db->where('imdbid', $id)->has(TABLE_FILES);
	}
	$data = array();
	$moviequary = Input('moviequary');
	if (strlen($moviequary) > 2) {
		if ($imdbid = getImdbid($moviequary)) {
			$results[] = new \Imdb\Title($imdbid);
		} else {

			$config = new \Imdb\Config();
			$config->language = 'en,hi,bn,te,ta,or,bho';
			$search = new \Imdb\TitleSearch($config);
			$results = $search->search($moviequary, array(\Imdb\TitleSearch::MOVIE), 5); // Optional second parameter restricts types returned
		}
	}

	foreach ($results as $result) { /* @var $result \Imdb\Title */

		if (@checkExistsMovie($result->imdbid())) {
			$button = '<button type="button" id="' . $result->imdbid() . '" class="ml-auto align-self-center btn btn-warning">Added</button>';
		} else {
			$button = '<button type="button" id="' . $result->imdbid() . '" class="ml-auto align-self-center btn btn-info selectmovie">Add</button>';
		}
		$data[] = ['id' => $result->imdbid(), 'thumb' => $result->photo(), 'title' => $result->title(), 'year' => $result->year(), 'button' => $button];
	}
	echo json_encode(['data' => $data]);
} else if ($currentAction == "imdbinfo") {

	$id = Input('id');
	if (!$id) {

		echo json_encode(['status' => 0, 'message' => 'IMDB ID Missing', 'data' => []]);
		exit;
	}
	$movie = new \Imdb\Title($id);
	if (!$movie) {
		echo json_encode(['status' => 0, 'message' => 'Failed Data Scarped', 'data' => []]);
		exit;
	}
	$casts = array();
	$cnt = 1;
	$moviecasts = $movie->cast();
	if ($moviecasts) {
		foreach ($moviecasts as $c) {
			$casts[] = $c["name"];
			if ($cnt == 3) {
				break;
			}
			$cnt++;
		}
	}
	$cnt = 1;
	$directors = array();
	$moviedirectors = $movie->director();
	if ($moviedirectors) {
		foreach ($moviedirectors as $d) {
			$directors[] = $d["name"];
			if ($cnt == 3) {
				break;
			}
			$cnt++;
		}
	}
	$directors = $directors ? implode(',', $directors) : '';
	$casts = $casts ? implode(',', $casts) : '';

	$currenttime = date('m-d H:i:s');
	$rdate = $movie->year();
	$releaseyear = $rdate . '-' . $currenttime;
	$data = [
		'imdbid' => $movie->imdbid(),
		'title' => $movie->title(),
		'thumb' => $movie->photo(),
		'release_date' => date('Y-m-d', strtotime($releaseyear)),
		'duration' => $movie->runtime(),
		'directors' => $directors,
		'stars' => $casts,
		'description' => $movie->tagline(),
		'genres' => $movie->genres(),
		'rating' => $movie->rating(),
		'total_rate' => $movie->votes()
	];

	echo json_encode(['status' => 1, 'message' => 'Successfuly Data Scarped', 'data' => $data]);
}
