<?php
/**
 * @author devops <devt.santu@gmail.com>
 */
$Notlogged = true;
require_once '../config/init.php';
if(isset($_SESSION['id']) && isset($_SESSION['username']))
Redirect(APP_URL . '/' . ADMIN_DIR);
if(Input('submit')){
    $username = Input('email');
    $password = md5(Input('password'));
    // $sub = $db->subQuery();
    // $sub->where('username',$username);
    // $sub->orWhere('email',$email);
    // $db->where(null,$sub);
     $db->where('(username="'.$username.'" OR email="'.$username.'")');
    $db->where("password", $password);
    if ($db->has(TABLE_ADMIN)) {
    $db->where('(username="' . $username . '" OR email="' . $username . '")');
    $db->where("password", $password);
    $user =   $db->getOne(TABLE_ADMIN,'id,username');
    $_SESSION['id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    echo 1;
    } else {
        echo 2;
    }

}

?>