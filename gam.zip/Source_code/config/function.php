<?php
if (detect_device())
  define('USER_DEVICE', 'm');
else {
  define('USER_DEVICE', 'p');
}
function getURL()
{
  $host = $_SERVER['HTTP_HOST'];
  $request_uri = $_SERVER['REQUEST_URI'];
  $request_uri = parse_url($request_uri, PHP_URL_PATH);
  return trim($host . $request_uri, '/');
}
function slug($str)
{
  $str = str_replace(' ', '-', trim($str));
  $str = str_replace('_', '-', $str);
  $str = preg_replace("/[^A-Za-z0-9-]/", "", $str);
  $str = str_replace('---', '-', $str);
  $str = str_replace('--', '-', $str);
  return strtolower($str);
}

function title($str)
{
  $str = str_replace(' ', '-', trim($str));
  $str = str_replace('_', '-', $str);
  $str = preg_replace("/[^A-Za-z0-9-]/", "", $str);
  $str = str_replace('---', '-', $str);
  $str = str_replace('--', '-', $str);
  $str = str_replace('-', ' ', $str);
  return ucwords($str);
}

function formatSize($size, $type = false, $round = 2)
{
  $sizes = array('byts', 'kb', 'mb', 'gb', 'tb');
  $total = count($sizes) - 1;
  for ($i = 0; $size > 1024 && $i < $total; $i++)
    $size /= 1024;
  if ($type == true)
    return array(round($size, $round), $sizes[$i]);
  return round($size, $round) . ' ' . $sizes[$i];
}
function fileDownload($Path, $fileName, $ext)
{
  switch ($ext) {
    case 'MP3':
      $mime = "audio/mpeg";
      break;
    case 'JPG':
      $mime = "image/jpg";
      break;
    default:
      $mime = "application/octet-stream";
  }

  header('Content-type: ' . $mime);
  header('Content-Disposition: attachment; filename="' . $fileName . '"');
  header('Content-Length: ' . filesize($Path));
  readfile($Path);
  exit;
}

function getLinks($id)
{
  global $db;
  if ($data = $db->where('file_id', $id)->orderBy('id')->get(TABLE_LINKS)) {
    return $data;
  }
  return false;
}
function getPageUrl($page, $link)
{
  return str_replace('{{PAGE}}', $page, $link);
}

function skyPageNavigate($totalpage, $start, $limit, $link)
{
  if ($totalpage != 1 && $totalpage != 0) {
    $pagination = '<nav aria-label="Page navigation"><ul class="pagination justify-content-center">';
    $totalLink = 5;
    $no_of_page = $totalpage;

    if ($start * $limit > $limit)
      $pagination .= '<li class="page-item"><a class="page-link" href="' . getPageUrl($start - 1, $link) . '"><i class="fa fa-caret-left" aria-hidden="true"></i> Prev</a></li>';
    // $pagination .= link_to('< Prev', $link.($start-1));

    $count_record = 0;
    $i = 1;
    if ($start >= $totalLink - floor($totalLink / 2))
      $i = $start - floor($totalLink / 2);

    if ($no_of_page > $totalLink)
      if (($no_of_page - $i) < $totalLink)
        $i = $i - ($totalLink - ($no_of_page - $i) - 1);

    for (; $i <= $no_of_page; $i++) {
      if ($start == $i)
        $pagination .= '<li class="page-item active" aria-current="page"><a href="#" class="page-link" tabindex="-1">' . $i . '</a></li>';
      else
        $pagination .=  '<li class="page-item"><a class="page-link" href="' . getPageUrl($i, $link) . '">' . $i . '</a></li>';
      //  $pagination .= link_to($i,$link.$i).'';
      $count_record = $count_record + 1;
      if ($count_record == $totalLink)
        break;
    }

    if ($start < $no_of_page) {
      $pagination .= '<li class="page-item"><a class="page-link" href="' . getPageUrl($start + 1, $link) . '">Next <i class="fa fa-caret-right" aria-hidden="true"></i></a></li>';
    }
    if ($start > 0)
      $pagination .= '</ul></nav>';
    return $pagination;
  }
}

function getAds($str)
{
  return $str . '_' . USER_DEVICE . '.php';
}

function detect_device()
{
  if (preg_match('/uc browser|ucweb|android|up.browser|up.link|windows ce|iemobile|mini|mmp|symbian|midp|wap|phone|pocket|mobile|pda|psp/i', $_SERVER['HTTP_USER_AGENT'])) {
    return true;
  }
  if (stristr($_SERVER['HTTP_USER_AGENT'], 'windows') && !stristr($_SERVER['HTTP_USER_AGENT'], 'windows ce')) {
    return false;
  }
  if (stristr($_SERVER['HTTP_ACCEPT'], 'text/vnd.wap.wml') || stristr($_SERVER['HTTP_ACCEPT'], 'application/vnd.wap.xhtml+xml')) {
    return true;
  }
  if (isset($_SERVER['HTTP_X_WAP_PROFILE']) || isset($_SERVER['HTTP_PROFILE']) || isset($_SERVER['X-OperaMini-Features']) || isset($_SERVER['UA-pixels'])) {
    return true;
  }
  $dmdarray = array(
    'acs-' => 'acs-', 'alav' => 'alav', 'alca' => 'alca', 'amoi' => 'amoi', 'audi' => 'audi', 'aste' => 'aste',
    'avan' => 'avan', 'benq' => 'benq', 'bird' => 'bird', 'blac' => 'blac', 'blaz' => 'blaz', 'brew' => 'brew', 'cell' => 'cell',
    'cldc' => 'cldc', 'cmd-' => 'cmd-', 'dang' => 'dang', 'doco' => 'doco', 'eric' => 'eric', 'hipt' => 'hipt', 'inno' => 'inno',
    'ipaq' => 'ipaq', 'java' => 'java', 'jigs' => 'jigs', 'kddi' => 'kddi', 'keji' => 'keji', 'leno' => 'leno', 'lg-c' => 'lg-c',
    'lg-d' => 'lg-d', 'lg-g' => 'lg-g', 'lge-' => 'lge-', 'maui' => 'maui', 'maxo' => 'maxo', 'midp' => 'midp', 'mits' => 'mits',
    'mmef' => 'mmef', 'mobi' => 'mobi', 'mot-' => 'mot-', 'moto' => 'moto', 'mwbp' => 'mwbp', 'nec-' => 'nec-', 'newt' => 'newt',
    'noki' => 'noki', 'opwv' => 'opwv', 'palm' => 'palm', 'pana' => 'pana', 'pant' => 'pant', 'pdxg' => 'pdxg', 'phil' => 'phil',
    'play' => 'play', 'pluc' => 'pluc', 'port' => 'port', 'prox' => 'prox', 'qtek' => 'qtek', 'qwap' => 'qwap', 'sage' => 'sage',
    'sams' => 'sams', 'sany' => 'sany', 'sch-' => 'sch-', 'sec-' => 'sec-', 'send' => 'send', 'seri' => 'seri', 'sgh-' => 'sgh-',
    'shar' => 'shar', 'sie-' => 'sie-', 'siem' => 'siem', 'smal' => 'smal', 'smar' => 'smar', 'sony' => 'sony', 'sph-' => 'sph-',
    'symb' => 'symb', 't-mo' => 't-mo', 'teli' => 'teli', 'tim-' => 'tim-', 'tosh' => 'tosh', 'treo' => 'treo', 'tsm-' => 'tsm-',
    'upg1' => 'upg1', 'upsi' => 'upsi', 'vk-v' => 'vk-v', 'voda' => 'voda', 'wap-' => 'wap-', 'wapa' => 'wapa', 'wapi' => 'wapi',
    'wapp' => 'wapp', 'wapr' => 'wapr', 'webc' => 'webc', 'winw' => 'winw', 'winw' => 'winw', 'xda-' => 'xda-'
  );
  // check if the first four characters of the current user agent are set as a key in the array
  if (isset($dmdarray[substr($_SERVER['HTTP_USER_AGENT'], 0, 4)])) {
    return true;
  }
}

function Redirect($url)
{
  header("Location: $url");
  exit;
}
