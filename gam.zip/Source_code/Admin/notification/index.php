<?php

/**
 * @author devops <devt.santu@gmail.com>
 */
require_once __DIR__ . '/../header.php'; ?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">

            <div class="d-flex justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Notification:</h6>
            </div>
        </div>
        <div class="card-body">
        <div class="row col-md-8">
            <form id="notiform" action="process.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="submit" value="send">
                <div class="form-row">
                    <div class="form-group col-md-8">
                        <label for="name">Title:</label>
                        <input type="text" name="title" class="form-control">
                    </div>
                    <div class="form-group col-md-12">
                        <label for="name">Body:</label>
                        <input type="text" name="body" class="form-control">
                    </div>
                    <div class="from-group col-md-6">
                        <label for="File">Thumb:</label>
                        <select name="thumbfrom" class="form-control" id="thumbfrom">
                            <option value="LOCAL">LOCAL</option>
                            <option value="EXTERNAL_LINK">URL</option>
                        </select>
                    </div>

                    <div id="thumb_file_display" class="form-group col-md-6">
                        <label for="thumb">Thumb File:</label>
                        <div class="custom-file">
                            <label for="thumb" class="custom-file-label">Choose File</label>
                            <input type="file" name="thumb" class="custom-file-input" id="thumbfile" />
                        </div>
                    </div>
                    <div id="thumb_url_display" style="display: none;" class="form-group col-md-6">
                        <label for="File">Thumb URL:</label>
                        <div class="input-group">
                            <input type="text" class="form-control" name="thumb_url" id="thumb_url" placeholder="Enter Valid URL">
                        </div>
                    </div>
                    <div class="from-group col-md-3">
                        <label for="File">Notify:</label>
                        <select name="notifyfrom" class="form-control" id="notifyfrom">
                           <option value="LINK">LINK</option>
                            <option value="FILE">MOVIE</option>
                            <option value="CAT">CATEGORY</option>
                        </select>
                    </div>

                    <div id="ex_notify" class="form-group col-md-9">
                        <label for="name">External Link:</label>
                        <input type="text" name="external_link" class="form-control">
                    </div>
                    <div id="filenotify" style="display: none;" class="from-group col-md-9">
                        <label for="file">Files:</label>
                        <select name="file" class="form-control" id="files">
                        <option value="">Search File</option>
                        </select>
                    </div>
                    <div id="catnotify" style="display: none;" class="from-group col-md-9">
                        <label for="category">Category:</label>
                        <select name="cat" class="form-control" id="category">
                        <option value="">Search Category</option>
                        </select>
                    </div>
                </div>
                <div class="m-2">
                <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
<?php
require_once __DIR__ . '/../footer.php';
?>