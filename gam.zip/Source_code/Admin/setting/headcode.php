<?php
/**
 * @author devops <devt.santu@gmail.com>
 */
require_once '../header.php';
if(!is_dir($RootPath . '/templates/widget')){
    mkdir($RootPath . '/templates/widget');
    WriteFile($RootPath . '/templates/widget/head.php','');
    WriteFile($RootPath . '/templates/widget/foot.php','');
}
$langsFiles = scandir($RootPath . '/templates/widget', SCANDIR_SORT_ASCENDING);

if (Input('save')) {
    $file = $RootPath . '/templates/widget/' . Input('wid');
    WriteFile($file, Input('contents'));
}

$content = '';
if (Input('wid') != '') {
    $filenm = $RootPath . '/templates/widget/' . Input('wid');
    if (file_exists($filenm)) {
        $lines = file($filenm);
        foreach ($lines as $line_num => $line) {
            $content .= $line;
        }
    }
}
?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="d-flex justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Header/Footer Editor</h6>
            </div>
        </div>
        <div class="card-body">
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <form action="" name="widgetforom" method="POST">
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="Select File">Select File</label>
                                <select name="wid" class="form-control" onchange="document.widgetforom.submit();">
                                    <option disabled selected>Select Area</option>
                                    <?php for ($i = 0; $i < count($langsFiles); $i++) :
                                        if (strpos($langsFiles[$i], '.') == 0 || $langsFiles[$i] == 'default.php')
                                            continue;
                                    ?>
                                        <option value="<?php echo $langsFiles[$i]; ?>" <?php if ($langsFiles[$i] == Input('wid')) echo ' selected'; ?>><?php echo str_replace('.php', '', $langsFiles[$i]); ?> </></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <?php if (Input('wid') != '') : ?>
                                <div class="form-group col-12">
                                    <label for="Contents">Editor </></label>
                                    <textarea name="contents" class="form-control" id="" cols="30" rows="10"><?php echo $content; ?></textarea>
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary m-2" value="Save" name="save" />
                                </div>
                            <?php endif; ?>
                        </div>
                    </form>

                </div>

            </div>

        </div>
    </div>
</div>

<?php
require_once '../footer.php';
?>