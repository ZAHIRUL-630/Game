<?php

/**
 * @author devops <devt.santu@gmail.com>
 */
header('Content-Type: application/json; charset=utf-8');
require_once '../config/init.php';
require_once $RootPath . '/config/language.php';

use WebPConvert\WebPConvert;
use Intervention\Image\ImageManagerStatic as Image;

$appname = Input('app_name') ? Input('app_name') : APP_NAME;
$sitehttps = Input('site_https') ? Input('site_https') : "false";
$sitetitle = Input('home_title') ? Input('home_title') : $title;
$sitedes = Input('home_des') ? Input('home_des') : $metadescription;
$sitekeywords = Input('home_keywords') ? Input('home_keywords') : $metakeywords;
$files_per_page = Input('files_per_page') ? Input('files_per_page') : FILES_PER_PAGE;
$cat_per_page = Input('cat_per_page') ? Input('cat_per_page') : CATEGORY_PER_PAGE;
$releted_files_limit = Input('releted_limit') ? Input('releted_limit') : RELETED_FILES_LIMIT;

$defaultads = Input('ads_network') ? Input('ads_network') : DEFAULT_ADS;
$thumbformat = Input('thumbnail_format') ? Input('thumbnail_format') : THUMB_FORMAT;
$thumb_quality = Input('thumb_quality') ? Input('thumb_quality') : THUMB_QUALITY;
$tplname = Input('tplname') ? Input('tplname') : TEMPLATE;
$advt_each = Input('advt_each') ? Input('advt_each') : ADVT_EACH;
$thumbog = Input('thumbog');
$ogimage = Input('ogimageurl') ? Input('ogimageurl') : $metaogimage;
$pushnotify = Input('webpush');
$onesignalid = Input('onesignalid');
$onesignalrest = Input('onesignalrest');
//Default

$cat_thumb_sizes = CATICON_SIZES;
$file_thumb_sizes = FILE_THUMB_SIZES;
$mp3_cover_size = MP3TAG_COVER;
$list_thumb = LIST_THUMB;
$preview_thumb = PREVIEW_THUMB;
$og_thumb = META_OG_THUMB;
$card_thumb = CARD_THUMB;

if ($_FILES['logo']['name']) {
    $path = $RootPath . '/assets/images/logo.png';
    if (UploadFile('logo', $path)) {
        $Image = Image::make($path);
        $Image->resize(40, null, function ($constraint) {
            $constraint->aspectRatio();
        });
        $Image->save($path, 95);
    }
}


if ($_FILES['ogimage']['name']) {
    $Imgwh = explode('x', $og_thumb);
    $path = $RootPath . '/assets/images/og.jpg';
    $Image = Image::make($_FILES['ogimage']['tmp_name']);
    $Image->resize($Imgwh[0], $Imgwh[1])->save($path, 95);
    $ogimage = APP_URL . '/assets/images/og.jpg';
}

if ($_FILES['thumb_watermark']['name']) {
    $Imgwh = explode('x', $preview_thumb);
    $rwh =  $Imgwh[0] / 2.70;
    $rwh = intval($rwh);
    $path = $RootPath . '/assets/images/watermark.png';
    $Image = Image::make($_FILES['thumb_watermark']['tmp_name']);
    $Image->resize($rwh, null, function ($constraint) {
        $constraint->aspectRatio();
    });
    $Image->save($path, 100);
}


$parsed_url = parse_url(APP_URL);
$scheme   = isset($parsed_url['scheme']) ? $parsed_url['scheme'] . '://' : '';
$host     = isset($parsed_url['host']) ? $parsed_url['host'] : '';
$path     = isset($parsed_url['path']) ? $parsed_url['path'] : '';
$old_url = $host . rtrim($path, '/');
$old_url = trim($old_url, '/');

$baseURL = $old_url;

if ($sitehttps == 1) {
    $app_URL = 'https://' . $old_url;
} else {
    $app_URL = 'http://' . $old_url;
}

if ($thumbog == "1")
    $orginalog = 1;
else {
    $orginalog = "0";
}

if ($pushnotify == 1) {
    WriteFile($RootPath . '/OneSignalSDKUpdaterWorker.js', "importScripts('https://cdn.onesignal.com/sdks/OneSignalSDKWorker.js');");
    WriteFile($RootPath . '/OneSignalSDKWorker.js', "importScripts('https://cdn.onesignal.com/sdks/OneSignalSDKWorker.js');");
    $webpush = 1;
} else {
    if (file_exists($RootPath . '/OneSignalSDKUpdaterWorker.js')) {
        unlink($RootPath . '/OneSignalSDKUpdaterWorker.js');
    }
    if (file_exists($RootPath . '/OneSignalSDKWorker.js')) {
        unlink($RootPath . '/OneSignalSDKWorker.js');
    }
    $webpush = "0";
}


$admindir = ADMIN_DIR;
$data = "<?php
define('BASE_URL','$baseURL');
define('APP_URL', '$app_URL');
define('APP_HTTPS','$sitehttps');
define('APP_NAME', '$appname');
define('TEMPLATE','$tplname');
define('ERROR_PAGE',false);
define('HOME_UPDATES_TYPE',1);
define('HOME_UPDATES_LIMIT', '25');
define('FILES_PER_PAGE', $files_per_page);
define('CATEGORY_PER_PAGE', $cat_per_page);
define('RELETED_FILES_LIMIT', $releted_files_limit);
define('ADMIN_DIR', '$admindir');
define('CATICON_SIZES', '$cat_thumb_sizes');
define('FILE_THUMB_SIZES','$file_thumb_sizes');
define('MP3TAG_COVER','$mp3_cover_size');
define('LIST_THUMB', '$list_thumb');
define('CARD_THUMB', '$card_thumb');
define('PREVIEW_THUMB', '$preview_thumb');
define('META_OG_THUMB', '$og_thumb');
define('THUMB_OGIMAGE',$orginalog);
define('ADS_NETWORK', 'ADSENSE,TABOOLA,OWNADS');
define('DEFAULT_ADS', '$defaultads');
define('ADVT_EACH','$advt_each');
define('THUMB_FORMAT', '$thumbformat');
define('THUMB_QUALITY', '$thumb_quality');
define('WEBPUSH', '$webpush');
define('WEBPUSH_SENDER_ID','$onesignalid');
define('WEBPUSH_REST_KEY','$onesignalrest');
//DATABASE TABLE 
define('TABLE_CAT', 'category');
define('TABLE_FILES', 'file');
define('TABLE_ADMIN', 'admin');
define('TABLE_DIRECTOR','directors');
define('TABLE_GENRE', 'genres');
define('TABLE_STAR','stars');
define('TABLE_LINKS','downlinks');
//HOME PAGE TITLE
$" . '' . "title = '$sitetitle';
$" . '' . "metadescription = '$sitedes';
$" . '' . "metakeywords = '$sitekeywords';
$" . '' . "metaogsitename = APP_NAME;
$" . '' . "metatwsite = APP_NAME;
$" . '' . "metaogimage = '$ogimage';
$" . '' . "metarobots = 'index,follow';";

$manifest = [
    "short_name" => $appname,
    "name" => $appname,
    "icons" => [
        [
            "src" => "/assets/images/icons-192.png",
            "type" => "image/png",
            "sizes" => "192x192"
        ],
        [
            "src" => "/assets/images/icons-512.png",
            "type" => "image/png",
            "sizes" => "512x512"
        ], [

            "src" => "/assets/images/maskble-192x192.png",
            "sizes" => "196x196",
            "type" => "image/png",
            "purpose" => "maskable"

        ]
    ],
    "start_url" => "/",
    "background_color" => "#212529",
    "display" => "standalone",
    "scope" => "/",
    "theme_color" => "#212529",
    "description" => $sitedes,
    "screenshots" => [
        [
            "src" => "/assets/images/screenshot-241x479.png",
            "type" => "image/png",
            "sizes" => "241x479"
        ],
        [
            "src" => "/assets/images/screen-381x543.png",
            "type" => "image/png",
            "sizes" => "381x543"
        ],
        [
            "src" => "/assets/images/screen-669x536.png",
            "type" => "image/png",
            "sizes" => "669x536"
        ]
    ],
    "gcm_sender_id" => ''
];
WriteFile($RootPath . '/config/config.php', $data);
WriteFile($RootPath . '/manifest.json', json_encode($manifest));
echo json_encode(['status' => 1, 'message' => 'Successfuly Updated']);
