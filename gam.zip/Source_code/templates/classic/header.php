<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once realpath(__DIR__ . '/../widget/head.php'); ?>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $title; ?></title>
    <link rel="canonical" href="<?php echo $AppProtocol . $request_path ?>">
    <?php if ($AmpURL) : ?>
        <link rel="amphtml" href="<?php echo $AmpURL; ?>">
    <?php endif; ?>
    <?php if ($schema) : ?>
        <script type="application/ld+json">
            <?php echo json_encode($schema); ?>
        </script>
    <?php endif; ?>
    <meta name="language" content="en">
    <meta name="theme-color" content="#343a40">
    <!-- Webmaster Seo Tag -->
    <meta name="title" content="<?php echo $title; ?>">
    <?php if ($metadescription) : ?>
        <meta name="description" content="<?php echo $metadescription; ?>">
    <?php endif; ?>
    <?php if ($metakeywords) : ?>
        <meta name="keywords" content="<?php echo $metakeywords; ?>">
    <?php endif; ?>
    <meta name="robots" content="<?php echo $metarobots; ?>">
    <!-- Open Graph Meta Tag -->
    <meta property="og:url" content="<?php echo $AppProtocol . $request_path ?>">
    <meta property="og:type" content="article">
    <meta property="og:title" content="<?php echo $title; ?>">
    <meta property="og:description" content="<?php echo $metadescription; ?>">
    <meta property="og:image" content="<?php echo $metaogimage; ?>">
    <!-- Fevicons -->
    <link rel="apple-touch-icon" type="image/png" sizes="192x192" href="/assets/images/icons-192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicon-16x16.png">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <link rel="manifest" href="/manifest.json">
    <link rel="stylesheet" href="/assets/js/dist/style.css">
</head>

<body>
    <header>
        <nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="<?php echo APP_URL; ?>"><img src="/assets/images/logo.png" width="40" height="40" alt="<?php APP_NAME; ?>">
                    <span class="fs-4 ms-2"><?php echo APP_NAME;?></span>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-uppercase" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                A to Z
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="<?php echo APP_URL.'/movies/1/a-to-z'.$endRoute;?>">A to Z Movies</a></li>
                                <li><a class="dropdown-item" href="<?php echo APP_URL.'/stars/1/a-to-z'.$endRoute;?>">A to Z Stars</a></li>
                                <li><a class="dropdown-item" href="<?php echo APP_URL.'/directors/1/a-to-z'.$endRoute;?>">A to Z Dirctors</a></li>
                                <li><a class="dropdown-item" href="<?php echo APP_URL.'/genres/1/a-to-z'.$endRoute;?>">A to Z Genres</a></li>
                            </ul>
                        </li>
                    </ul>
                    <form class="d-flex" action="<?php echo APP_URL . '/search/list'; ?>" method="GET">
                        <div class="input-group me-2">
                            <input class="form-control" type="text" name="q" placeholder="Search" value="<?php echo isset($searchq) ? $searchq : ''; ?>" aria-label="Search">
                            <div class="input-group-append">
                                <select name="search" aria-label="SearchType" class="form-control">
                                    <option value="movie">Movie</option>
                                    <option value="star">Star</option>
                                    <option value="director">Director</option>
                                </select>
                            </div>
                        </div>
                        <button class="btn btn-danger" type="submit">Search</button>
                    </form>
                </div>
            </div>
        </nav>
        <div class="nav-scroller container p-0 bg-light rounded-top shadow-sm">
            <nav class="nav nav-underline" aria-label="Secondary navigation">
                <a class="nav-link" href="<?php echo APP_URL; ?>"><i class="fa fa-home" aria-hidden="true"></i>
                    Home</a>
                <?php include(__DIR__ . '/_navbar.php'); ?>
            </nav>
        </div>
    </header>
    <?php include(getAds($AdsPath . '/all_page_top')); ?>