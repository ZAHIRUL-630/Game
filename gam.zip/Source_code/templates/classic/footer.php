<?php include(getAds($AdsPath . '/all_page_bottom')); ?>
<footer class="bg-dark">
  <div class="p-2 text-center text-white">
    <a class="text-white" href="<?php echo APP_URL; ?>">&copy; <?php echo date("Y")." ".APP_NAME; ?></a> <br>
    <?php include(__DIR__ . '/services.html'); ?>
  </div>
</footer>
<!-- <div class="fab fab__push" data-checked="false">
  <div class="fab__ripple"></div>
  <i class="fa fa-bell-o" aria-hidden="true"></i>
</div> -->
<script src="/assets/js/dist/bundle.js"></script>
<?php require_once realpath(__DIR__ . '/../widget/foot.php'); ?>
<?php if(WEBPUSH==1 && ONESIGNAL_ID){
    echo '<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
    <script>
      window.OneSignal = window.OneSignal || [];
      OneSignal.push(function() {
        OneSignal.init({
          appId: "'.ONESIGNAL_ID.'",
        });
      });
    </script>';
}?>
</body>
</html>