<?php 
error_reporting(0);
if(file_exists(__DIR__.'/../lock.txt'))
{
    die();
    exit;
}
$errors = array();
$version = '1';
function getInput($val)
{
 if(isset($_POST[$val]))
 return filter_var($_POST[$val],FILTER_SANITIZE_STRING);
 return;
}
function cURLPOST($url,$data=array()) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch,CURLOPT_TIMEOUT,3000);
    $data = curl_exec($ch);
    curl_close ($ch);
    return json_decode($data,true);
}
if(isset($_POST['action'])){
$domain = getInput('domain');
$orderid = getInput('order_id'); 
$dbhost = getInput('dbhost');
$dbport = getInput('dbport');
$dbuser = getInput('dbuser');
$dbpass = getInput('dbpass');
$dbname= getInput('dbname');
$admindir = getInput('admin_dir');

if(empty($admindir)){
    array_push($errors,'Admin Directory cannot be empty');
}
if(empty($domain)){
    array_push($errors,'Site URL can not be empty');
}
if(empty($orderid)){
    array_push($errors,'Order ID can not be empty');
}
if(empty($dbhost)){
    array_push($errors,'DB Host Cannot be empty');
}

if(empty($dbport)){
    array_push($errors,'DB Port Cannot be empty');
}

if(empty($dbuser)){
    array_push($errors,'DB User Cannot be empty');
}

if(empty($dbname)){
    array_push($errors,'DB Name Cannot be empty');
}
if(!extension_loaded('gd') && !function_exists('gd_info')){
    array_push($errors,'Required GD Library for Thumbnail Generator');
}

if (!version_compare(PHP_VERSION, '5.6.0', '>=')){
   array_push($errors,'Required PHP version 5.6 or more');

}
if(!function_exists('mysqli_connect')){
    array_push($errors,'Required MySQLi PHP extension');
}
if (!extension_loaded('fileinfo')){
    array_push($errors,'fileinfo extension required');
}

if(!extension_loaded('zip')){
    array_push($errors,'Required Zip extension');
}

if(!function_exists('curl_init')){
    array_push($errors,'Required cURL PHP extension');
}

if(!ini_get('allow_url_fopen')){
    array_push($errors,'Enable allow_url_fopen in your php.ini');   
}


if(count($errors)==0){
$conn = new mysqli($dbhost, $dbuser,$dbpass, $dbname,$dbport);
if ($conn->connect_error) {
array_push($errors, 'DB Connnection Failed: '. $conn->connect_error);
}
if(count($errors)==0){
   $data = cURLPOST(base64_decode('aHR0cHM6Ly9pbWRldm9wcy5pbi9lbnZhdG8vdmVyaWZ5LnBocA'),['domain'=>$_SERVER['HTTP_HOST'],'version'=>$version,'lic'=>$orderid]);
   if(!$data){
    array_push($errors, 'Please Try Again');
   } else {
       if($data['status']==2){
        array_push($errors, $data['message']);  
       }elseif($data['status'] == 3){
        array_push($errors, $data['message']);
    }
   }
   if(count($errors)==0){
  foreach($data['database'] as $dburl){
    $filename = $dburl;
    // Temporary variable, used to store current query
    $templine = '';
    // Read in entire file
    $lines = file($filename);
    // Loop through each line
    foreach ($lines as $line) {
    // Skip it if it's a comment
    if (substr($line, 0, 2) == '--' || $line == '')
    continue;
    // Add this line to the current segment
    $templine .= $line;
    $query = false;
    // If it has a semicolon at the end, it's the end of the query
    if (substr(trim($line), -1, 1) == ';') {
    // Perform the query
    $query = $conn->query($templine);
    // Reset temp variable to empty
    $templine = '';
    }
    }
}
$parsed_url = parse_url($domain);
$scheme   = isset($parsed_url['scheme']) ? $parsed_url['scheme'] . '://' : '';
$host     = isset($parsed_url['host']) ? $parsed_url['host'] : '';
$path     = isset($parsed_url['path']) ? $parsed_url['path'] : '';
$baseURL = $host.rtrim($path,'/');
$appURL = $scheme.trim($baseURL,'/');

if($scheme=="https://"){
$https_status = "1";
} else {
$https_status = "false"; 
}
if($admindir!='Admin'){
    if(rename(__DIR__.'/../Admin',__DIR__.'/../'.$admindir)){
    $admindir = $admindir;
    }
    else {  
    $admindir = 'Admin';
    }
    } else {
    $admindir = 'Admin';
    }

$configdata = "<?php
define('BASE_URL','$baseURL');
define('APP_URL', '$appURL');
define('APP_HTTPS','$https_status');
define('APP_NAME', 'Movie CMS');
define('TEMPLATE', 'classic');
define('ERROR_PAGE',false);
define('HOME_UPDATES_TYPE',1);
define('HOME_UPDATES_LIMIT', '25');
define('FILES_PER_PAGE', 12);
define('CATEGORY_PER_PAGE', 12);
define('RELETED_FILES_LIMIT', 5);
define('ADMIN_DIR', '$admindir');
define('CATICON_SIZES', '54x80,117x172,182x268');
define('FILE_THUMB_SIZES','54x80,117x172,182x268');
define('MP3TAG_COVER','182x268');
define('LIST_THUMB', '54x80');
define('CARD_THUMB', '117x172');
define('PREVIEW_THUMB', '182x268');
define('META_OG_THUMB', '182x268');
define('THUMB_OGIMAGE',1);
define('ADS_NETWORK', 'ADSENSE,TABOOLA,OWNADS'); //ADS NETWORK
define('DEFAULT_ADS', 'ADSENSE');
define('ADVT_EACH',6);
define('THUMB_FORMAT', 'jpg');
define('THUMB_QUALITY', '100');
define('WEBPUSH', '0');
define('WEBPUSH_SENDER_ID','');
define('WEBPUSH_REST_KEY','');
//DATABASE TABLE 
define('TABLE_CAT', 'category');
define('TABLE_FILES', 'file');
define('TABLE_ADMIN', 'admin');
define('TABLE_DIRECTOR','directors');
define('TABLE_GENRE', 'genres');
define('TABLE_STAR','stars');
define('TABLE_LINKS','downlinks');
//HOME PAGE TITLE
$".''."title = 'Latest Hindi Bollywood Movie Watch Online and Download Free';
$".''."metadescription = 'Watch free and download hindi bollywood movie hindi, Hollywood Movie Hindi Dubbed and South Indian Movie and many more';
$".''."metakeywords = 'hindi bollywood movie, hollywood movie, south indian latest movie, hindi dubbed movie download';
$".''."metaogsitename = APP_NAME;
$".''."metatwsite = APP_NAME;
$".''."metaogimage = APP_URL.'/assets/images/og.jpg';
$".''."metarobots = 'index,follow';";
//HANDLE CONFIGTURE
$databaseData ='<?php
$dbhost = "'.$dbhost.'"; //DATABASE HOST
$dbport = "'.$dbport.'"; //DATABASE PORT
$dbuser = "'.$dbuser.'"; //DATABASE USERNAME
$dbpass = "'.$dbpass.'"; //DATABASE USER PASSWORD
$dbname = "'.$dbname.'"; //DATABASE NAME
$dbprefix = ""; // DATATBASE PREFIX
$dbcharset = "utf8"; //DATABASE CHARTSET';

$file = fopen(__DIR__.'/../config/database.php',"w");
fwrite($file,$databaseData);
fclose($file);

$file = fopen(__DIR__.'/../config/config.php',"w");
fwrite($file,$configdata);
fclose($file);

$file = fopen(__DIR__.'/../lock.txt',"w");
fwrite($file,'Locked');
fclose($file);

if(!is_dir(__DIR__.'/../upload_file'))
mkdir(__DIR__.'/../upload_file');

if(!is_dir(__DIR__.'/../upload_file/folderthumb'))
mkdir(__DIR__.'/../upload_file/folderthumb');

if(!is_dir(__DIR__.'/../upload_file/notification'))
mkdir(__DIR__.'/../upload_file/notification');

if(!is_dir(__DIR__.'/../upload_file/genrethumb'))
mkdir(__DIR__.'/../upload_file/genrethumb');

if(!is_dir(__DIR__.'/../upload_file/starthumb'))
mkdir(__DIR__.'/../upload_file/starthumb');

if(!is_dir(__DIR__.'/../upload_file/directorthumb'))
mkdir(__DIR__.'/../upload_file/directorthumb');

session_start();
$_SESSION['id'] = 1;
$_SESSION['username'] = 'admin';
header('Location: '.$appURL.'/'.$admindir.'/setting/index.php');
exit;
   }

}

}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP INSTALLER</title>
    <style>
body {
 background-color: #000;
 color:#000;
 max-width: 500px;
 margin: auto;
}
body * {
 margin:0;
 padding:0;
 font-family:verdana,"Comic Sans MS",Helvetica,sans-serif;
}
a {
 text-decoration:none;
 color:#a00
}
a:hover {
 text-decoration:none;
 color:#00f
}
.form-group label {
  display: block;
  padding: 4px;
  font-weight: bold;
  color:teal;
  margin: 5px;
}
.form-control{
  font-size: 20px;
  width: 80%;
  height: 30px;
  border: 2px solid #ccc;
}
.alert{
  background: #dedede;
  color: red;
  padding: 9px;
  border-radius: 4px;
}
.installform{
    padding: 20px;
    margin: 10px;
    border-radius: 10px;
    background-color: #fff;
}
.header{
    font-size: 25px;
       font-weight: bold;
      color: #00f;
      text-align: center;
}
.support_txt{
  font-size: small;
  text-align: center;
  padding: 5px;
  color: blueviolet;
}
.btn-submit{
  display: block;
  padding: 10px;
  margin-top:10px;
  text-align: center;
  background: #ff0000;
  color: white;
  font-weight: bold;
}
.centerText{
    text-align: center;
}
</style>
</head>
<body>
    <div class="installform">
        <div class="header">INSTALLER</div>
        <div class="support_txt">Support: Telegram : @mamber_adder_paid1 <br>Email: devt.santu@gmail.com <br></div>
     <?php if(count($errors) > 0){
         echo '<div class="alert">';
foreach($errors as $error){
    echo $error.'<br>';
}

echo '</div>';
     };?>
     <form action="" method="POST">
        <div class="form-group">
        <label for="host">Site Url:</label>
        <input type="text" name="domain" class="form-control" value="<?php echo 'https://'.$_SERVER['HTTP_HOST'];?>">
    </div>
    <div class="form-group">
        <label for="host">Licence Key: <small><a href="https://imdevops.in/envato/?domain=<?php echo $_SERVER['HTTP_HOST'];?>" target="_blank" rel="noopener noreferrer">Generate Key</a></small></label>
        <input type="text" name="order_id" class="form-control" value="<?php echo isset($orderid)?$orderid:'';?>">
    </div>
    <div class="form-group">
        <label for="host">Database Host:</label>
        <input type="text" name="dbhost" class="form-control" value="<?php echo isset($dbhost)?$dbhost:'localhost';?>">
    </div>
    <div class="form-group">
        <label for="host">Database Port:</label>
        <input type="text" name="dbport" class="form-control" value="3306">
    </div>
    <div class="form-group">
        <label for="host">Database User:</label>
        <input type="text" name="dbuser" class="form-control" value="<?php echo isset($dbuser)?$dbuser:'';?>">
    </div>
    <div class="form-group">
        <label for="host">Database Password:</label>
        <input type="text" name="dbpass" class="form-control" value="<?php echo isset($dbpass)?$dbpass:'';?>">
    </div>
    <div class="form-group">
        <label for="host">Database Name:</label>
        <input type="text" name="dbname" class="form-control" value="<?php echo isset($dbname)?$dbname:'';?>">
    </div>
    <div class="form-group">
        <label for="host">Admin DIR:</label>
        <input type="text" name="admin_dir" class="form-control" value="Admin">
    </div>
    <div class="centerText">
    <button type="submit" name="action" class="btn-submit">Install</button>
    </div>
    </form>
    </div>
</body>
</html>