<?php
if ($output2) {
    $id = $output2[2];
    $page = $output2[1];
    $sort = 'default';
} else {
    $id = $output[1];
    $page = 1;
    $sort = 'default';
}
unset($output, $output2);
if ($data = $db->where('old_slug', $id)->getOne(TABLE_CAT, 'slug')) {
    Redirect(APP_URL . '/category/' . $data['slug']);
    exit;
}
$category = $db->where('slug', $id)->getOne(TABLE_CAT);
$catThumb = '';
if (!$category) {
    if (ERROR_PAGE == true) {
        require __DIR__ . '/ErrorPage.php';
    } else {
        Redirect(APP_URL);
    }
    exit;
}
$categories = array();
$files = array();
$sort = "category";
switch ($sort) {
    case "download":
        $orderby = array('download', 'DESC');
        break;
    case "az":
        $orderby = array('name', 'ASC');
        break;
    case "new":
        $orderby = array('id', 'DESC');
        break;
    default:
        $orderby = array('pos', 'ASC');
}

if ($category['subcate'] == 0) {
    $db->pageLimit = FILES_PER_PAGE;
    $pagelimit = FILES_PER_PAGE;
    //
    $db->join(TABLE_CAT . ' c', 'f.cid=c.id', "INNER");
    $db->orderBy('f.' . $orderby[0], $orderby[1]);
    $db->orderBy('f.id');
    $db->where('f.cid', $category['id']);
    $db->where('f.status', 1);
    $files = $db->paginate(TABLE_FILES . ' f', $page, 'f.slug,f.thumb,f.name,f.duration,f.release_date,c.name as category_name,c.folder,c.thumb as category_thumb');

    $title = $category['meta_title'] ? $category['meta_title'] . ' - ' . APP_NAME : str_replace(array('{{CATEGORY_NAME}}'), array($category['name']), $lang['FILELIST_TITLE']) . ' - ' . APP_NAME;
    $metadescription = $category['meta_des'] ? $category['meta_des'] : str_replace(array('{{CATEGORY_NAME}}'), array($category['name']), $lang['FILELIST_META_DESCRIPTION']);
    $metakeywords = $category['meta_keyw'] ? $category['meta_keyw'] : str_replace(array('{{CATEGORY_NAME}}'), array($category['name']), $lang['FILELIST_META_KEYWORDS']);
    $autotags = str_replace(array('{{CATEGORY_NAME}}'), array($category['name']), $lang['FILELIST_AUTO_TAG']);
    $pageLink = APP_URL . '/category/{{PAGE}}/' . $category['slug'] . $endRoute;
} else {
    $db->where('status', 1);
    $db->where('parentid', $category['id']);
    $db->orderBy($orderby[0], $orderby[1]);
    $db->pageLimit = CATEGORY_PER_PAGE;
    $pagelimit = CATEGORY_PER_PAGE;
    $categories  = $db->paginate(TABLE_CAT . ' c', $page, 'c.slug,c.name,c.folder,c.totalitem,c.thumb');
    $pageLink = APP_URL . '/category/{{PAGE}}/' . $category['slug'] . $endRoute;
    $title = $category['meta_title'] ? $category['meta_title'] : str_replace(array('{{CATEGORY_NAME}}'), array($category['name']), $lang['CATLIST_TITLE']) . ' - ' . APP_NAME;
    $metadescription = $category['meta_des'] ? $category['meta_des'] : str_replace(array('{{CATEGORY_NAME}}'), array($category['name']), $lang['CATLIST_META_DESCRIPTION']);
    $metakeywords = $category['meta_keyw'] ? $category['meta_keyw'] : str_replace(array('{{CATEGORY_NAME}}'), array($category['name']), $lang['CATLIST_META_KEYWORDS']);
    $autotags = str_replace(array('{{CATEGORY_NAME}}'), array($category['name']), $lang['CATLIST_AUTO_TAG']);
}
$totalPage = $db->totalPages;

$sq = $db->subQuery();
$sq->where('parentid', $category['parentid']);
$sqIds =  $sq->get(TABLE_CAT, null, 'id');
$YouMayMovies = $db
    ->join(TABLE_CAT . ' c', 'f.cid=c.id', "INNER")
    ->orderBy('RAND()')
    ->where('f.status', 1)->where('f.cid', $sqIds, 'IN')->get(TABLE_FILES . ' f', 5, 'f.name,f.slug,f.thumb,f.duration,f.view,f.release_date,c.folder');

if (!$YouMayMovies) {
    $YouMayMovies = $db
        ->join(TABLE_CAT . ' c', 'f.cid=c.id', "INNER")
        ->orderBy('RAND()')
        ->where('f.status', 1)->get(TABLE_FILES . ' f', 5, 'f.name,f.slug,f.thumb,f.duration,f.view,f.release_date,c.folder');
}

$parentids = array_filter(explode('/', $category['folder']));
array_shift($parentids);
array_pop($parentids);
$bpos = 1;
$breadhtml = '<nav aria-label="breadcrumb"><ol class="breadcrumb mt-2"><li class="breadcrumb-item"><a href="' . APP_URL . '">Home</a></li>';
if ($parentids) {
    $breadcrumbs = $db->where('id', $parentids, 'IN')->orderBy('id', 'ASC', $parentids)->get(TABLE_CAT);
    foreach ($breadcrumbs as $bread) {
        $bpos++;
        $breadcrumb[] =  [
            "@type" => "ListItem",
            "position" => $bpos,
            "item" => [
                "@id" => APP_URL . '/category/' . $bread['slug'] . $endRoute,
                "name" => $bread['name']
            ]
        ];
        $breadhtml .= '<li class="breadcrumb-item"><a href="' . APP_URL . '/category/' . $bread['slug'] . $endRoute . '">' . $bread['name'] . '</a></li>';
    }
}
$breadcrumb[] =  [
    "@type" => "ListItem",
    "position" => $bpos+1,
    "item" => [
        "@id" =>  $AppProtocol . $request_uri,
        "name" =>  $category['name']
    ]
];
$breadhtml .= '<li class="breadcrumb-item"><a href="' . $AppProtocol . $request_uri  . '">' . $category['name'] . '</a></li>';
$breadhtml .= '</ol></nav>';
$schema = [
    "@context" => "https://schema.org",
    "@type" => "BreadcrumbList",
    "itemListElement" => $breadcrumb
];
// print_r($db->getLastQuery());
// exit;


if ($category['thumb']) {
    $thumbWH = explode('x', PREVIEW_THUMB);
    $catThumb = APP_URL . '/upload_file/folderthumb/' . PREVIEW_THUMB . '/' . $category['thumb'];
    if (THUMB_OGIMAGE == 1)
        $metaogimage = APP_URL . '/upload_file/folderthumb/' . META_OG_THUMB . '/' . $category['thumb'];
}
require_once $Template . '/header.php';
require_once $Template . '/Category.php';
require_once $Template . '/footer.php';
