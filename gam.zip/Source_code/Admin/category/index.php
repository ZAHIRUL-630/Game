<?php
/**
 * @author devops <devt.santu@gmail.com>
 */
require_once __DIR__ . '/../header.php';
$pathc = '';
$pathc = '<li class="breadcrumb-item"><a href="index.php">Home</a></li>';
if(Input('parentid')){
$parentid = Input('parentid');
    $category = $db->where('id',$parentid)->getOne(TABLE_CAT);
    $title = $category['name'];
    $parentids = array_filter(explode('/',$category['folder']));
    array_shift($parentids);

    if($parentids){
    $breadcrumbs = $db->where('id',$parentids,'IN')->orderBy('id','ASC',$parentids)->get(TABLE_CAT);
    foreach($breadcrumbs as $bread){
        if($bread['totalitem'] > 0)
    $pathc .= '<li class="breadcrumb-item"><a href="?parentid='.$bread['id'].'">'.$bread['name'].'</a></li>';
      else {
        $pathc .= '<li class="breadcrumb-item"><a href="?parentid='.$bread['id'].'">'.$bread['name'].'</a></li>';
 
      }
}
    }
} else {
    $category['subcate'] = 0;
    $category['totalitem'] = 0;
    $title = "Categories";
    $parentid = '0';
}
?>
<div class="container-fluid">

<?php if($parentid){?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
  <?php echo $pathc;?>
  </ol>
</nav>
<?php } ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">

            <div class="d-flex justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary"><?php echo $title;?></h6>
             <?php 
             if($category['subcate'] > 0 || $category['totalitem'] ==  0 ||  $parentid ==0 )
               echo '<a class="btn btn-info btn-sm" href="?parentid='.$parentid.'" id="addcat">Add Category</a>';
               ?>
            </div>
        </div>
        <div class="card-body">
            <?php
             if($parentid)
            if($category['subcate']==0):?>
            <p><a href="../files/create.php?cid=<?php echo $parentid;?>" class="btn btn-info">Add Movie</a></p>
          <?php endif;?>
            <div class="table-responsive">
                <table id="datalist" name="categories" class="table table-striped table-bordered nowrap catlist" width="100%" cellspacing="0">
                    <thead class="bg-info text-white">
                        <tr>
                            <th>Id</th>
                            <th>Thumb</th>
                            <th>Category Name</th>
                            <th>Order</th>
                            <th>Status</th>
                            <th width="15">Added</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="ModalCategory" tabindex="-1" role="dialog" aria-labelledby="Modal" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <form id="catform" name="catform">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ModalLabel">Catgory Management</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-row">
                        <div class="from-group col-md-6">
                        <label for="ccccc">Category Name</label>
                        <input type="text" name="category_name" id="category_name" value="" placeholder="" class="form-control">
                        </div>
                        <div class="from-group col-md-6">
                        <label for="sss">Slug:</label>
                        <input type="text" name="slug" id="slug" value="" placeholder="" class="form-control">
                        </div>
                        <div class="from-group col-md-6">
                            <label for="File">Thumb:</label>
                            <select name="thumbfrom" class="form-control" id="thumbfrom">
                                <option value="LOCAL">LOCAL</option>
                                <option value="EXTERNAL_LINK">URL</option>
                            </select>
                        </div>

                        <div id="thumb_file_display" class="form-group col-md-6">
                            <label for="thumb">Thumb File:</label>
                            <div class="custom-file">
                                <label for="thumb" class="custom-file-label">Choose File</label>
                                <input type="file" name="thumb" class="custom-file-input" id="thumbfile" />
                            </div>
                        </div>
                        <div id="thumb_url_display" style="display: none;" class="form-group col-md-6">
                            <label for="File">Thumb URL:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="thumb_url" id="thumb_url" placeholder="Enter Valid URL">
                            </div>
                        </div>
                        <div class="col-md-4 text-center">
                        Watermark Postion:
                        <div>
                        <input type="radio" name="w_pos" value="top-left" checked>
                        <input type="radio" name="w_pos" value="top">
                        <input type="radio" name="w_pos" value="top-right"><br>
                        <input type="radio" name="w_pos" value="left">
                        <input type="radio" name="w_pos" value="center">
                        <input type="radio" name="w_pos" value="right"><br>
                        <input type="radio" name="w_pos" value="bottom-left">
                        <input type="radio" name="w_pos" value="bottom">
                        <input type="radio" name="w_pos" value="bottom-right"><br>
                        </div>
                        </div>
                       <div id="thumbnail" style="display: none;">
                        <div class="col-12">
                                 <div>Thumbnail:</div>
                                 <div>
                                 <img src="" class="img-thumbnail" id="thumb" alt="thumbnal" width="200" height="200">
                                <button type="button" class="removethumb btn btn-danger">Delete</button>
                                 </div>
                        </div>
                       </div>
                        <div class="col-12">
                        <div class="form-group m-2">
                                 <label for="desc">Description:</label>
                                <textarea name="category_des" id="category_des" class="form-control htmleditor" rows="10"></textarea>
                            </div>
                        </div>
                        
                        <div class="col-md-8 form-group">
                      <label for="name">Title</label>
                      <input type="text" name="meta_title" id="meta_title" class="form-control">
                      </div>

                      <div class="col-md-12 form-group">
                      <label for="meta_keyw">Keywords</label>
                      <input type="text" name="meta_keyw" id="meta_keyw" class="form-control">
                      </div>
                      <div class="col-md-12 form-group">
                      <label for="meta_des">Description</label>
                      <input type="text" name="meta_des" id="meta_des" class="form-control">
                      </div>
                        <div class="col-3">
                        <div class="input-group m-2">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Order:</span>
                                </div>
                                <input type="text" name="category_order" id="category_order" value="0" placeholder="" class="form-control">
                            </div>
                        </div>
                        <div class="form-group col-12">
                           <label for="appname">New Badge:</label>
                                <input type="checkbox" class="form-control" data-toggle="switch" id="newtag" name="newtag" value="1" />
                                <label for="appname">Update Badge:</label>
                                <input type="checkbox" class="form-control" data-toggle="switch" id="updatetag" name="updatetag" value="1" />
                            
                        </div>
                            <div class="form-group col-12">
                            <label for="added_home">Added Navbar:</label>
                            <input type="checkbox" class="form-control" data-toggle="switch" id="added_home" name="added_home" value="1" />
                            
                            <label for="status">Status:</label>
                            <input type="checkbox" class="form-control" id="status" data-toggle="switch" name="status" value="1" checked/>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="id" id="id" />
                    <input type="hidden" name="parentid" value="<?php echo $parentid;?>" id="parentid" />
                    <input type="hidden" name="submit" id="action" value="" />
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php
require_once __DIR__ . '/../footer.php';
?>