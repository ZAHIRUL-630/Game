<?php
$searchq = filter_input(INPUT_GET, 'q', FILTER_SANITIZE_STRING);
$type = filter_input(INPUT_GET, 'search', FILTER_SANITIZE_STRING);
$page = (isset($_GET['page'])) ? filter_input(INPUT_GET, 'page', FILTER_SANITIZE_STRING) : 1;
$collection = array();
$files = array();
$categories = array();
$orderby = ['name', 'ASC'];
$schar = '';
if (strlen($searchq) >= 3) {
    $schar = str_split($searchq, 3);
    $schar = implode('', $schar);
}
if ($type == 'movie') {
    $pagelimit = FILES_PER_PAGE;
    $db->pageLimit = $pagelimit;
    $db->join(TABLE_CAT . ' c', 'f.cid=c.id', "INNER");
    $db->orderBy('f.' . $orderby[0], $orderby[1]);
    $db->orderBy('f.id');
    $db->where('f.name', '%' . $searchq . '%', 'LIKE');
    $db->where('f.status', 1);
    $files = $db->paginate(TABLE_FILES . ' f', $page, 'f.id,f.slug,f.thumb,f.name,f.duration,f.release_date,c.name as category_name,c.folder,c.thumb as category_thumb');
    $pageLink = APP_URL . '/search/list?q=' . $searchq . '&search=' . $type . '&page={{PAGE}}' . $endRoute;
    $ReletedAlso = '';
    $db->join(TABLE_CAT . ' c', 'f.cid=c.id', "INNER");
    if($files)
    $db->where('f.id',array_column($files,'id'),'NOT IN');
    $YouMayMovies =  $db->where('f.name', '%' . $schar . '%', 'LIKE')->get(TABLE_FILES . ' f', 5, 'f.name,f.slug,f.thumb,f.duration,f.view,f.release_date,c.folder');
}

if ($type == 'director' || $type == 'star') {
    $dbTable = ($type == "director") ? TABLE_DIRECTOR : TABLE_STAR;
    $pagelimit = FILES_PER_PAGE;
    $db->pageLimit = $pagelimit;
    $db->where('name', '%' . $searchq . '%', 'LIKE');
    $db->orderBy('name', 'ASC')->orderBy('id');
    $db->where('status', 1);
    $collection = $db->paginate($dbTable, $page, 'id,name,thumb,slug');
    $pageLink = APP_URL . '/search/list?q=' . $searchq . '&search=' . $type . '&page={{PAGE}}' . $endRoute;
    if($collection){
        $db->where('id',array_column($collection,'id'),'NOT IN');
    }
    $db->where('name', '%' . $schar . '%', 'LIKE');
    $db->where('status', 1)->orderBy('RAND()');
    $ReletedAlso = $db->get($dbTable, 5, 'name,slug,thumb');
    $YouMayMovies = '';
}

$totalPage = $db->totalPages;
$breadhtml = '<nav aria-label="breadcrumb"><ol class="breadcrumb mt-2"><li class="breadcrumb-item"><a href="' . APP_URL . '">Home</a></li>';
$breadcrumb[] =  [
    "@type" => "ListItem",
    "position" => 2,
    "item" => [
        "@id" => $AppProtocol . $request_uri,
        "name" => 'Search'
    ]
];
$breadhtml .= '<li class="breadcrumb-item"><a href="' . $AppProtocol . $request_uri . '">Search</a></li>';
$breadhtml .= '</ol></nav>';
$schema = [
    "@context" => "https://schema.org",
    "@type" => "BreadcrumbList",
    "itemListElement" => $breadcrumb
];
$title = $searchq ? $searchq . ' - Search Result' : 'Search Result';
$title .= ' - ' . APP_NAME;
require_once $Template . '/header.php';
require_once $Template . '/Search.php';
require_once $Template . '/footer.php';
