<main class="container bg-light shadow-sm rounded-bottom border-top pb-2">
  <div class="row">
    <!-- Start Main Container -->
    <div class="col-12 col-lg-8">
      <?php include(getAds($AdsPath . '/preview_before')); ?>
      <?php echo $breadhtml; ?>
      <h1 class="p-2 mb-3 text-dark text-truncate fs-5 fw-normal text-uppercase border-bottom"><?php echo $file['name'] . ' (' . $releasedate . ') Movie Download'; ?></h1>
      <div class="row">
        <div class="col-12 col-md-4">
          <div class="card">
            <div class="p-2">
              <img data-bs-toggle="tooltip" title="<?php echo $file['name'] . ' (' . $releasedate . ')'; ?>" src="<?php echo APP_URL . '/assets/images/movie.svg'; ?>" data-src="<?php echo $thumb; ?>" alt="<?php echo $file['name'] . ' (' . $releasedate . ')'; ?>" class="lazy mx-auto d-block rounded" width="<?php echo $thumbWH[0]; ?>" height="<?php echo $thumbWH[1]; ?>">
            </div>
            <p class="text-center text-danger"><i class="fa fa-imdb" aria-hidden="true"></i> IMDB Rating: <span class="rating"><i class="fa fa-star" aria-hidden="true"></i></span> <?php echo $file['rating'];?></p>
          </div>
        </div>
        <div class="col-12 col-md-8">
          <h2 class="text-center p-2 mb-2 text-truncate fs-6 fw-normal border-bottom"><?php echo $file['name']; ?></h2>
          <div class="card card-body p-0 movie-show-i fw-light">
            <p><i class="fa fa-calendar" aria-hidden="true"></i> Year: <?php echo $file['release_date']; ?></p>
            <p><i class="fa fa-clock-o" aria-hidden="true"></i> Duration: <?php echo $file['duration']; ?> <span class="small">Min</span></p>
            <p><i class="fa fa-info-circle" aria-hidden="true"></i> Genre: <?php echo $genres; ?></p>
            <p><i class="fa fa-user-o" aria-hidden="true"></i> Stars: <?php echo $stars; ?></p>
            <p><i class="fa fa-film" aria-hidden="true"></i> Director: <?php echo $directors; ?></p>
            <p><i class="fa fa-eye" aria-hidden="true"></i> Views: <?php echo $file['view']; ?>+</p>
          </div>
          <div class="d-flex m-2 justify-content-between">
            <?php if ($PlayLinks) {
              echo '<button type="button" onclick="watchbutton();" data-bs-toggle="modal" data-bs-target="#modalDialog" class="btn btn-primary watchbutton"><i class="fa fa-file-video-o" aria-hidden="true"></i> Watch</button>';
            }
            if ($DownLinks) {
              echo '<button type="button" onclick="downbutton();" data-bs-toggle="modal" data-bs-target="#modalDialog" class="btn btn-danger downbutton"><i class="fa fa-download" aria-hidden="true"></i> Download</button>';
            }
            echo '<button type="button" id="share" onclick="share();" class="btn btn-success"><i class="fa fa-share" aria-hidden="true"></i> Share</button>';
            ?>
          </div>
        </div>
      </div>
      <?php
      include(getAds($AdsPath . '/preview_between'));
      if ($file['des']) {
        echo '<div class="card card-body p-2 my-2 rounded fw-light">
        <span class="text-secondary">Description/Story: </span> ' . $file['des'] . '
      </div>';
      }
      include(getAds($AdsPath . '/preview_after'));
      ?>
    </div>
    <!-- End Main Container -->

    <!-- Start Sidebar -->
    <div class="col-12 col-lg-4">
      <?php include(getAds($AdsPath . '/sidebar_before')); ?>
      <h3><i class="fa fa-random" aria-hidden="true"></i> You May Also Like</h3>
      <div class="row row-cols-3 row-cols-sm-4 row-cols-md-6 row-cols-lg-3 bg-light g-1 g-sm-2 mb-3">
        <?php
        $files = $YouMayMovies;
        require __DIR__ . '/_files_list.php';
        unset($YouMayMovies);
        ?>
      </div>
    </div>
    <!-- End Sidebar -->
    <div class="col-md-4">
      <h3><i class="fa fa-film" aria-hidden="true"></i> Releted Movies</h3>
      <ul class="row row-cols-2 g-1 list-inline sb-cols">
        <?php foreach ($ReletedFiles as $mv) {
          $mvdate =  date("Y", strtotime($mv['release_date']));
          echo '<li class="col">
        <a data-bs-toggle="tooltip" title="' . $mv['name'] . ' (' . $mvdate . ')" href="' . APP_URL . '/movie/' . $mv['slug'] . '" class="list-group-item"><i class="fa fa-caret-right" aria-hidden="true"></i> ' . $mv['name'] . ' (' . $mvdate . ')</a>
    </li>';
        }
        ?>
      </ul>
    </div>
    <div class="col-md-4">
      <h3><i class="fa fa-users" aria-hidden="true"></i> Releted Stars / Cast</h3>
      <ul class="row row-cols-2 g-1 list-inline sb-cols">
        <?php foreach ($reletedstars as $star)
          echo '<li class="col">
        <a data-bs-toggle="tooltip" title="' . $star['name'] . '" href="' . APP_URL . '/star/' . $star['slug'] . '" class="list-group-item"><i class="fa fa-caret-right" aria-hidden="true"></i> ' . $star['name'] . '</a>
    </li>';
        ?>
      </ul>
    </div>
    <div class="col-md-4">
      <h3><i class="fa fa-users" aria-hidden="true"></i> Releted Directors</h3>
      <ul class="row row-cols-2 g-1 list-inline sb-cols">
        <?php foreach ($releteddirector as $director)
          echo '<li class="col">
        <a data-bs-toggle="tooltip" title="' . $director['name'] . '" href="' . APP_URL . '/director/' . $director['slug'] . '" class="list-group-item"><i class="fa fa-caret-right" aria-hidden="true"></i> ' . $director['name'] . '</a>
    </li>';
        ?>
      </ul>
    </div>
  </div>

  <div class="modal fade" id="modalDialog" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h4 id="modalLabel" class="modal-title fs-5">Movie Watch and Download</h4>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="sharemovie"></div>
          <?php if ($DownLinks) : ?>
            <div id="downloadmovie" class="card mb-3 shadow-sm">
              <h3><i class="fa fa-download" aria-hidden="true"></i> Download</h3>
              <table class="table table-striped table-bordered dltable">
                <thead>
                  <tr class="fw-light">
                    <th class="w-30" scope="col">#</th>
                    <th class="w-40" scope="col">Link:</th>
                    <th class="w-30" scope="col"></th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($DownLinks as $dlink) : ?>
                    <tr>
                      <td><?php echo $dlink['name']; ?></td>
                      <td class="trunacate w-40"><?php echo $dlink['link']; ?></td>
                      <td><button type="button" class="btn btn-outline-danger btn-sm" onclick="openlink(this);" value="<?php echo $dlink['link']; ?>" class="text-danger"><i class="fa fa-cloud-download" aria-hidden="true"></i> Click Here</button></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
          <?php if ($PlayLinks) : ?>
            <div id="watchmovie" class="card mb-3 shadow-sm">
              <ul class="nav nav-pills mb-3" id="playlist-tab" role="tablist">
                <?php
                $cnt = 0;
                foreach ($PlayLinks as $pl) {
                  $cssclass = ($cnt == 0) ? ' active' : '';
                  $selected = ($cnt == 0) ? "true" : "false";
                  echo  '<li class="nav-item" role="presentation">
                  <button class="btn btn-outline-secondary btn-sm m-1' . $cssclass . '" id="pills-watch-' . $pl['id'] . '" data-bs-toggle="pill" data-bs-target="#watchmovie' . $pl['id'] . '" type="button" role="tab" aria-controls="watchmovie' . $pl['id'] . '" aria-selected="' . $selected . '">' . $pl['name'] . '</button></li>';
                  $cnt++;
                } ?>
              </ul>
              <div class="tab-content">
                <?php
                $cnt = 0;
                foreach ($PlayLinks as $pl) {
                  $cssclass = ($cnt == 0) ? 'tab-pane fade show active' : 'tab-pane fade';
                  echo '<div class="' . $cssclass . '" id="watchmovie' . $pl['id'] . '" role="tabpanel" aria-labelledby="pills-watch-' . $pl['id'] . '">
                  <div class="ratio ratio-16x9">
                  <iframe class="card-img-bottom lazy" data-src="' . $pl['link'] . '" frameborder="0" allowfullscreen></iframe>
                   </div>
                  </div>';
                  $cnt++;
                } ?>
              </div>
            </div>
          <?php endif;
          ?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  <p class="card card-body p-2 my-2 fw-light"><?php echo $autotags; ?></p>
</main>