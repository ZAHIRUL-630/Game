<?php

/**
 * @author devops <devt.santu@gmail.com>
 */
header('Content-Type: application/json; charset=utf-8');
require_once '../config/init.php';
$ThumbFolder = 'genrethumb';
$DB_TABLE = TABLE_GENRE;
$currentAction = Input('submit');
if ($currentAction == 'list') {
    $searchValue = dtsValue();
    if ($searchValue) {
        $db->where('name', '%' . $searchValue . '%', 'LIKE');
    }
    if (InputArray('order')) {
        $column = dtOrderby();
        if ($column == 2)
            $db->orderBy('name', dtOrderby(false));
        else if ($column == 5) {
            $db->orderBy('added_home', dtOrderby(false));
        } else
            $db->orderBy('id', dtOrderby(false));
    } else {
        $db->orderBy('pos', 'ASC');
        $db->orderBy('id');
    }
    if (Input('length') != -1) {
        $models = $db->withTotalCount()->get($DB_TABLE, array(dtlimit(), dtlimit(false)));
    } else {
        $models = $db->withTotalCount()->get($DB_TABLE);
    }

    $numRows = $db->totalCount;
    $data = array();
    $size = explode(',', CATICON_SIZES);
    foreach ($models as $ml) {
        if ($ml['thumb'] != "") {
            $thumb = '<img class="border border-dark" src="../../upload_file/' . $ThumbFolder . '/' . $size[0] . '/' . $ml['thumb'] . '" alt="Icon" width="60" height="60">';
        } else {
            $thumb = '';
        }
        $row = array();
        $row[] = $ml['id'];
        $row[] = $thumb;
        $row[] = $ml['name'];
        $row[] = ($ml['status'] == true) ? '<span id="' . $ml['id'] . '" class="status btn btn-success btn btn-sm">Active</span>' : '<span id="' . $ml['id'] . '" class="status btn btn-warning btn-sm">Block</span>';
        $row[] = $ml['pos'];
        $row[] = ($ml['added_home'] == true) ? '<span class="badge badge-success">YES</span>' : '<span class="badge badge-light">NO</span>';
        $row[] = '<button type="button" name="edit" id="' . $ml["id"] . '" class="edit btn btn-success btn-sm mr-2">Edit</button><button type="button" name="delete" id="' . $ml["id"] . '" class="delete btn btn-danger btn-sm">Delete</button>';
        $data[] = $row;
    }
    $output = array(
        "draw"                =>    intval(Input('draw')),
        "recordsTotal"      =>  $numRows,
        "recordsFiltered"     =>     $numRows,
        "data"                =>   $data
    );
    echo json_encode($output);
} else if ($currentAction == 'delete') {

    $id = Input('id');

    $model = $db->where('id', $id)->getOne($DB_TABLE);
    if (!$model) {
        $data = [
            'status' => 0,
            'message' => 'Delete Unsucessfuly'
        ];
        exit;
    }
    $thumbnailname = $model['thumb'];
    if ($thumbnailname) {
        $saveTo = $RootPath . '/upload_file/' . $ThumbFolder;
        $appsizes = explode(',', CATICON_SIZES);
        foreach ($appsizes as $wh) {
            $Imgwh = explode('x', $wh);
            $ImgDir = $saveTo . '/' . $wh;
            if (file_exists($ImgDir . '/' . $thumbnailname))
                unlink($ImgDir . '/' . $thumbnailname);
        }
        $newthumbname = pathinfo($thumbnailname, PATHINFO_FILENAME);
        $catCover = $RootPath . '/upload_file/' . $ThumbFolder . '/' . MP3TAG_COVER . '/' . $newthumbname . '.jpg';
        if (file_exists($catCover)) {
            unlink($catCover);
        }
    }

    if ($db->where('id', Input('id'))->delete($DB_TABLE)) {
        $data = [
            'status' => 1,
            'message' => 'Deleted Sucessfuly'
        ];
    } else {
        $data = [
            'status' => 0,
            'message' => 'Delete Unsucessfuly'
        ];
    }

    echo json_encode($data);
} else if ($currentAction == 'getOne') {
    $db->where('id', Input('id'));
    $modelInfo = $db->getOne($DB_TABLE);
    $size = explode(',', CATICON_SIZES);
    if ($modelInfo['thumb'] != '') {
        $thumbnail = '../../upload_file/' . $ThumbFolder . '/' . $size[0] . '/' . $modelInfo['thumb'];
    } else {
        $thumbnail = '';
    }
    $data = [
        'id' => $modelInfo['id'],
        'name' => $modelInfo['name'],
        'thumb' => $thumbnail,
        'status' => $modelInfo['status'],
        'slug' => $modelInfo['slug'],
        'meta_title' => $modelInfo['meta_title'],
        'meta_keyw' => $modelInfo['meta_keyw'],
        'meta_des' =>  $modelInfo['meta_des'],
        'pos' => $modelInfo['pos'],
        'added_home' => $modelInfo['added_home'],

    ];
    echo json_encode($data);
} else if ($currentAction == 'create' || $currentAction == 'edit') {
    $name = Input('name');
    $status = Input('status') ? Input('status') : 0;
    $slug =  slug($name);
    $action = $currentAction;
    $thumbnailname = '';
    if (!$name) {
        $data = [
            'status' => 0,
            'message' => 'Name can not be empty'
        ];
        echo json_encode($data);
        exit;
    }
    if (Input('id'))
        $db->where('id', Input('id'), '!=');
    if ($db->where('slug', $slug)->has($DB_TABLE)) {
        $data = [
            'status' => 0,
            'message' => 'Already exists'
        ];
        echo json_encode($data);
        exit;
    }

    if ($action == 'create') {
        $data = [
            'name' => $name,
            'slug' => $slug,
            'status' => $status,
            'meta_title' => Input('meta_title'),
            'meta_keyw' => Input('meta_keyw'),
            'meta_des' => Input('meta_des'),
            'pos' => Input('pos') ? Input('pos') : 0,
            'added_home' => Input('added_home') ? Input('added_home') : 0,
            'created_at' => $db->now()
        ];
        $id = $db->insert($DB_TABLE, $data);
    } else {
        if (!Input('id')) {
            $data = [
                'status' => 0,
                'message' => 'Id Missing'
            ];
        }

        $data = [
            'name' => $name,
            'slug' => $slug,
            'status' => $status,
            'meta_title' => Input('meta_title'),
            'meta_keyw' => Input('meta_keyw'),
            'meta_des' => Input('meta_des'),
            'pos' => Input('pos') ? Input('pos') : 0,
            'added_home' => Input('added_home') ? Input('added_home') : 0,
            'created_at' => $db->now()
        ];
        if ($db->where('id', Input('id'))->update($DB_TABLE, $data)) {
            $id = Input('id');
        }
    }

    if ($id) {
        $model = $db->where('id', $id)->getOne($DB_TABLE);
        $w_pos = Input('w_pos') ? Input('w_pos') : 'top-left';
        $saveToThumb = $RootPath . '/upload_file/' . $ThumbFolder . '/';
        $thumbfrom = Input('thumbfrom');
        if ($thumbfrom == 'EXTERNAL_LINK') {
            $thumbURL = trim(Input('thumb_url'));
            $thumb_ext = pathinfo($thumbURL, PATHINFO_EXTENSION);

            if ($thumbURL && $thumb_ext) {
                $tmp_thumbname = 'tmp_thumb.' . $thumb_ext;
                $thumbnailname = $model['thumb'] ? pathinfo($model['thumb'], PATHINFO_FILENAME) : uniqid('thumb_');

                $saveThumb = $RootPath . '/upload_file/' . $ThumbFolder . '/' . $tmp_thumbname;
                if (urlCopy($thumbURL, $saveThumb)) {
                    genThumb($saveThumb, $saveToThumb, $thumbnailname, $w_pos,false,CATICON_SIZES);
                    unlink($saveThumb);
                }
            }
        } else {
            if ($_FILES['thumb']['name']) {
                $thumbnailname = $model['thumb'] ? pathinfo($model['thumb'], PATHINFO_FILENAME) : uniqid('thumb_');
                genThumb($_FILES['thumb']['tmp_name'], $saveToThumb, $thumbnailname, $w_pos,false,CATICON_SIZES);
            }
        }

        if ($thumbnailname) {
            $db->where('id', $id)->update($DB_TABLE, ['thumb' => $thumbnailname ? $thumbnailname . '.' . THUMB_FORMAT : $model['thumb']]);
        }



        echo json_encode([
            'status' => 1,
            'message' => 'Created/Update sucessfuly'
        ]);
    } else {
        echo json_encode([
            'status' => 0,
            'message' => 'Created Unsucessfuly'
        ]);
    }
} else if ($currentAction == "removethumb") {
    if ($id = Input('id')) {
        $model = $db->where('id', $id)->getOne($DB_TABLE);
        $thumbnailname = $model['thumb'];
        if ($thumbnailname) {
            $saveTo = $RootPath . '/upload_file/' . $ThumbFolder;
            $appsizes = explode(',', CATICON_SIZES);
            foreach ($appsizes as $wh) {
                $Imgwh = explode('x', $wh);
                $ImgDir = $saveTo . '/' . $wh;
                if (file_exists($ImgDir . '/' . $thumbnailname))
                    unlink($ImgDir . '/' . $thumbnailname);
            }
            $newthumbname = pathinfo($thumbnailname, PATHINFO_FILENAME);
            $catCover = $RootPath . '/upload_file/' . $ThumbFolder . '/' . MP3TAG_COVER . '/' . pathinfo($model['thumb'], PATHINFO_FILENAME) . '.jpg';
            if (file_exists($catCover)) {
                unlink($catCover);
            }
        }
        $db->where('id', $id)->update($DB_TABLE, ['thumb' => '']);
    }
    echo json_encode([
        'status' => 1,
        'message' => 'Thumbnail Removed'

    ]);
} elseif ($currentAction == "statusUpdater") {

    $id = Input('id');
    $status = $db->where('id', $id)->getValue($DB_TABLE, 'status');

    if ($status == 1) {
        $data = ['status' => 0];
    } else {
        $data = ['status' => 1];
    }
    $db->where('id', $id)->update($DB_TABLE, $data);
    echo json_encode([
        'status' => 1,
        'message' => 'Status Updated'

    ]);
} else if ($currentAction == "multipledelete") {
    $ids = InputArray('ids');
    if (!$ids) {
        echo json_encode(['status' => 0, 'message' => 'Sorry No item Selected']);
        exit;
    }
    $cnt = 0;
    foreach ($ids as $id) {
        if ($id) {
            $model = $db->where('id', $id)->getOne($DB_TABLE);
            if (!$model) {
                continue;
            }
            $thumbnailname = $model['thumb'];
            if ($thumbnailname) {
                $saveTo = $RootPath . '/upload_file/' . $ThumbFolder;
                $appsizes = explode(',', CATICON_SIZES);
                foreach ($appsizes as $wh) {
                    $Imgwh = explode('x', $wh);
                    $ImgDir = $saveTo . '/' . $wh;
                    if (file_exists($ImgDir . '/' . $thumbnailname))
                        unlink($ImgDir . '/' . $thumbnailname);
                }
                $newthumbname = pathinfo($thumbnailname, PATHINFO_FILENAME);
                $catCover = $RootPath . '/upload_file/' . $ThumbFolder . '/' . MP3TAG_COVER . '/' . $newthumbname . '.jpg';
                if (file_exists($catCover)) {
                    unlink($catCover);
                }
            }

            if ($db->where('id', $id)->delete($DB_TABLE)) {
                $cnt++;
            }
        }
    }

    echo json_encode(['status' => 1, 'message' => 'Deleted Total: ' . $cnt . ' Items']);
}
