</div>
<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
        <span>Copyright &copy; <?php echo date("Y")." ".APP_NAME; ?></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="LogoutModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="LogoutModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="<?php echo $AdminURL; ?>/user/logout.php">Logout</a>
            </div>
        </div>
    </div>
</div>
<!-- Bootstrap core JavaScript-->
<script src="<?php echo $AdminURL; ?>/assets/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo $AdminURL; ?>/assets/js/jquery-ui.min.js"></script>
<script src="<?php echo $AdminURL; ?>/assets/js/sticky.min.js"></script>
<script src="<?php echo $AdminURL; ?>/assets/vendor/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script src="<?php echo $AdminURL; ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $AdminURL; ?>/assets/vendor/bootstrap-tagsinput-latest/jquery.tagsinput.min.js"></script>
<script src="<?php echo $AdminURL; ?>/assets/vendor/progress-js/bootstrap-waitingfor.min.js"></script>
<script src="<?php echo $AdminURL; ?>/assets/vendor/bs-custom-file-input/dist/bs-custom-file-input.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="<?php echo $AdminURL; ?>/assets/vendor/summernote-0.8.18-dist/summernote.min.js"></script>
<script src="<?php echo $AdminURL; ?>/assets/vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="<?php echo $AdminURL; ?>/assets/vendor/bootstrap-sweetalert-master/dist/sweetalert.min.js"></script>
<script src="<?php echo $AdminURL; ?>/assets/vendor/DataTables/datatables.min.js"></script>
<script src="<?php echo $AdminURL; ?>/assets/vendor/select2/js/select2.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="<?php echo $AdminURL; ?>/assets/js/sb-admin-2.min.js"></script>

<script src="<?php echo $AdminURL; ?>/assets/js/app.min.js"></script>
<script src="<?php echo $AdminURL; ?>/assets/js/index.js"></script>
<!-- Page level custom scripts -->
</body>

</html>