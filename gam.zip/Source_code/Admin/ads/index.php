<?php
/**
 * @author devops <devt.santu@gmail.com>
 */
require_once __DIR__ . '/../header.php';
?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">

            <div class="d-flex justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Ads Changer</h6>
                <a class="btn btn-info btn-sm" href="#" id="adchanger_add">Add New Changer</a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="datalist" name="adschanger" class="table table-bordered adschanger" width="100%" cellspacing="0">
                <thead class="bg-info text-white">
                        <tr>
                            <th>Id</th>
                            <th>URL</th>
                            <th>ADS</th>
                            <th></th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="adchangermodal" tabindex="-1" role="dialog" aria-labelledby="Modal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form id="adchangerform">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modallabel">ADS Changer</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-row">
                        <div class="col-md-12">
                            <div class="input-group m-2">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">URL</span>
                                </div>
                                <input type="text" name="ads_url" id="ads_url" class="form-control" placeholder="Which URL" />
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="input-group m-2">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">ADS NETWORK</span>
                                </div>
                                <select name="ads_network" id="ads_network" class="form-control">
                                   <option value="OFF">OFF</option>
                                   <?php
                                   $adsnetwrk = explode(',',ADS_NETWORK);
                                   foreach($adsnetwrk as $adk) {
                                    echo '<option value="'.$adk.'">'.$adk.'</option>';
                                   }?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="submit" id="adschanger_action" value="create" />
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button type="submit" id="submitbutton" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php
require_once __DIR__ . '/../footer.php';
?>