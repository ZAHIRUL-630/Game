var stars = $(".stars").DataTable({
    responsive: true,
    dom: "Bflrtip",
    select: {
      style: "os",
      selector: "td:nth-child(2)",
    },
    buttons: [
      "selectAll",
      "selectNone",
      {
        text: "Delete",
        className: "btn btn-danger",
        action: function () {
          var ids = stars.rows({ selected: true }).ids().toArray();
          var count = stars.rows({ selected: true }).count();
          if (count > 0) {
            DeleteMultiple(ids, count);
          } else {
            swal("Error", "You Have no Item Seleted for Deleted", "warning");
          }
        },
      },
    ],
    lengthChange: true,
    lengthMenu: [
      [10, 25, 50, -1],
      [10, 25, 50, "All"],
    ],
    processing: true,
    serverSide: true,
    order: [],
    ajax: {
      url: "process.php",
      type: "POST",
      data: {
        submit: "list",
      },
      dataType: "json",
    },
    columnDefs: [
      {
        targets: [1, 3, 4],
        orderable: false,
      },
      { width: 60, targets: 1 },
    ],
    rowId: function (a) {
      return a[0];
    },
    pageLength: 10,
  });

  $("#add_stars").click(function (e) {
    e.preventDefault();
    $("#id").val("");
    $("#action").val("create");
    $("#mlabel").html("<i class='fa fa-plus'></i> Add Stars");
    $("#thumbnail").hide();
    $("#modalform").modal("show");
  });

  $(".stars").on("click", ".edit", function (e) {
    e.preventDefault();
    var id = $(this).attr("id");
    var action = "getOne";
    $("#mlabel").html("<i class='fa fa-plus'></i> Edit Stars");
    $("#thumbnail").hide();
    $("#starsform")[0].reset();
    $("#action").val("edit");
    $.ajax({
      url: "process.php",
      type: "POST",
      data: {
        id: id,
        submit: action,
      },
      dataType: "json",
      success: function (data) {
        $("#name").val(data.name);
        $("#id").val(data.id);
        $("#meta_title").val(data.meta_title);
        $("#meta_keyw").val(data.meta_keyw);
        $("#meta_des").val(data.meta_des);
        if (data.status == "1") {
          var isChecked2 = $("#status").prop("checked");
          if (isChecked2 == false) {
            $("#status").click();
          }
        }
        if (data.thumb != "") {
          $("#thumbnail").show();
          $("#thumb").attr("src", data.thumb);
        }
        $("#modalform").modal("show");
      },
    });
  });

  $(document).on("submit", "#starsform", function (event) {
    event.preventDefault();
    if ($("#name").val() == "") {
      swal("Error", "Please Fill Director Name", "warning");
      return false;
    }
    $("#submit").attr("disabled", "disabled");
    var formcat = $("#starsform")[0];
    var formData = new FormData(formcat);
    $.ajax({
      url: "process.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (data) {
        $("#submit").attr("disabled", false);
        if (data.status == 1) {
          $("#thumb_url_display").hide();
          $("#thumb_file_display").show();
          $("#starsform")[0].reset();
          $("#modalform").modal("hide");
          $("#submit").attr("disabled", false);
          stars.ajax.reload();
          swal("Success!", data.message, "success");
        } else {
          swal("Error!", data.message, "warning");
        }
      },
    });
  });