<?php
/**
 * @author devops <devt.santu@gmail.com>
 */
header('Content-Type: application/json');
require_once '../config/init.php';
if(Input('submit')=='change'){
    $id = $_SESSION['id'];
    $username = Input('username');
    $email = Input('email');
    $oldpass = Input('old_pass');
    $newpass = Input('new_pass');
    $confirm_pass = Input('confirm_pass');

    if ($oldpass == '' || $username =='' || $email=='') {

        echo  json_encode(['status' => '0', 'message' => 'Please Fill Details']);
        exit;
    }

    if($newpass!=$confirm_pass){

      echo  json_encode(['status'=>'0','message'=>'Confirm Password does not match']);
      exit;
    }

    if($db->where('id',$id)->where('password',md5($oldpass))->has(TABLE_ADMIN)){
 
        if($newpass){
      $db->where('id',$id)->update(TABLE_ADMIN,['username'=>$username,'email'=>$email,'password'=>md5($newpass)]);
        } else {
            $db->where('id', $id)->update(TABLE_ADMIN, ['username' => $username, 'email' => $email]);
        }
        echo  json_encode(['status' => '1', 'message' => 'Successfuly Changed']);
        exit;
    } else {
        echo  json_encode(['status' => '0', 'message' => 'Old Password does not match']);
        exit;
    }
}