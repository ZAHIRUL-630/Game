<?php
$ModelTable = TABLE_DIRECTOR;
$ModelDIR = 'directorthumb';
if ($output2) {
    $id = $output2[2];
    $page = $output2[1];
    $sort = 'default';
} else {
    $id = $output[1];
    $page = 1;
    $sort = 'default';
}
unset($output,$output2);
switch ($sort) {
    case "download":
        $orderby = array('download', 'DESC');
        break;
    case "az":
        $orderby = array('name', 'ASC');
        break;
    case "new":
        $orderby = array('id', 'DESC');
        break;
    default:
        $orderby = array('id', 'DESC');
}
$model = $db->where('slug', $id)->getOne($ModelTable);
$thumbWH = explode('x', PREVIEW_THUMB);
$thumb = '';
$ReletedAlso = array();
if ($model) {
    $name = $model['name'];
    $title = $model['meta_title'] ? $model['meta_title'] : str_replace(array('{{DIRECTOR_NAME}}'), array($name), $lang['DIRECTOR_TITLE']) . ' - ' . APP_NAME;
    $metadescription = $model['meta_des'] ? $model['meta_des'] : str_replace(array('{{DIRECTOR_NAME}}'), array($name), $lang['DIRECTOR_META_DESCRIPTION']);
    $metakeywords = $model['meta_keyw'] ? $model['meta_keyw'] : str_replace(array('{{DIRECTOR_NAME}}'), array($name), $lang['DIRECTOR_META_KEYWORDS']);

    $releasedate = date('d M, Y', strtotime($model['created_at']));
    $slug = $model['slug'];
    if ($model['thumb']) {
        $thumb = APP_URL . '/upload_file/' . $ModelDIR . '/' . PREVIEW_THUMB . '/' . $model['thumb'];
        if (THUMB_OGIMAGE == 1)
            $metaogimage = APP_URL . '/upload_file/' . $ModelDIR . '/' . META_OG_THUMB . '/' . $model['thumb'];
    }
    $ReletedAlso = $db->where('status', 1)->where('id', $model['id'], '<')->orderBy('RAND()')->get($ModelTable, 6, 'name,slug,thumb');
} else {
    $name = ucwords(str_replace('-', ' ', $id));
    $releasedate = '';
    $slug = $id;
}
$title = str_replace(array('{{DIRECTOR_NAME}}'), array($name), $lang['DIRECTOR_TITLE']) . ' - ' . APP_NAME;
$metadescription = str_replace(array('{{DIRECTOR_NAME}}'), array($name), $lang['DIRECTOR_META_DESCRIPTION']);
$metakeywords = str_replace(array('{{DIRECTOR_NAME}}'), array($name), $lang['DIRECTOR_META_KEYWORDS']);

$pageLink = APP_URL . '/director/{{PAGE}}/' . $slug . $endRoute;
$autotags = str_replace('{{DIRECTOR_NAME}}', $name, $lang['DIRECTOR_AUTO_TAG']);

$db->pageLimit = FILES_PER_PAGE;
$pagelimit = FILES_PER_PAGE;
$db->join(TABLE_CAT . ' c', 'f.cid=c.id', "INNER");
$db->orderBy('f.' . $orderby[0], $orderby[1]);
$db->orderBy('f.id');
$db->where('f.director', '%' . $name . '%', 'LIKE');
$db->where('f.status', 1);
$files = $db->paginate(TABLE_FILES . ' f', $page, 'f.name,f.thumb,f.slug,f.duration,f.release_date,c.folder');

if (!$ReletedAlso) {
    $ReletedAlso = $db->where('status', 1)->orderBy('RAND()')->get($ModelTable, 5, 'name,slug,thumb');
}
$totalPage = $db->totalPages;
$fchar = str_split($name,1);
$fchar = strtolower($fchar[0]);
$breadhtml = '<nav aria-label="breadcrumb"><ol class="breadcrumb mt-2"><li class="breadcrumb-item"><a href="' . APP_URL . '">Home</a></li>';
$breadcrumb[] =  [
    "@type" => "ListItem",
    "position" => 2,
    "item" => [
        "@id" => APP_URL.'/directors/1/'.$fchar,
        "name" => 'Directors'
    ]
];
$breadcrumb[] =  [
    "@type" => "ListItem",
    "position" => 3,
    "item" => [
        "@id" => $AppProtocol.$request_uri,
        "name" => $name
    ]
];
$breadhtml .= '<li class="breadcrumb-item"><a href="' .APP_URL.'/directors/1/'.$fchar . '">Directors</a></li>';
$breadhtml .= '<li class="breadcrumb-item"><a href="' . $AppProtocol.$request_uri . '">' . $name . '</a></li>';
$breadhtml .= '</ol></nav>';
$schema = [
    "@context" => "https://schema.org",
    "@type" => "BreadcrumbList",
    "itemListElement" => $breadcrumb
];
require_once $Template . '/header.php';
require_once $Template . '/Director.php';
require_once $Template . '/footer.php';
