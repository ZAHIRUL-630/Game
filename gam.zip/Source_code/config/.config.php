<?php
define('BASE_URL','127.2.2.2');
define('APP_URL', 'http://127.2.2.2');
define('APP_HTTPS','false');
define('APP_NAME', 'iMuzik');
define('TEMPLATE', 'classic');
define('ERROR_PAGE',false);
define('HOME_UPDATES_TYPE',1);
define('HOME_UPDATES_LIMIT', '25');
define('FILES_PER_PAGE', 12);
define('CATEGORY_PER_PAGE', 12);
define('RELETED_FILES_LIMIT', 5);
define('ADMIN_DIR', 'Admin');
define('CATICON_SIZES', '90x90,240x240,400x400');
define('FILE_THUMB_SIZES','90x90,240x240,400x400');
define('MP3TAG_COVER','400x400');
define('LIST_THUMB', '90x90');
define('PREVIEW_THUMB', '240x240');
define('META_OG_THUMB', '240x240');
define('THUMB_OGIMAGE',1);
define('ADS_NETWORK', 'ADSENSE,TABOOLA,OWNADS'); //ADS NETWORK
define('DEFAULT_ADS', 'ADSENSE');
define('ADVT_EACH',6);
define('THUMB_FORMAT', 'webp');
define('THUMB_QUALITY', '100');
define('WEBPUSH', '0');
define('ONESIGNAL_ID','');
define('ONESIGNAL_REST','');
//DATABASE TABLE 
define('TABLE_CAT', 'category');
define('TABLE_FILES', 'file');
define('TABLE_ADMIN', 'admin');

//HOME PAGE TITLE
$title = 'Download Top DjSong, Mp3 Songs, Remix Dj Song';
$metadescription = 'Free Download New Dj Songs, Bollywood Song, Latest Remix Dj Song, Mp3 Song';
$metakeywords = 'dj song download, dj song 2021, hindi new dj song download';
$metaogsitename = APP_NAME;
$metatwsite = APP_NAME;
$metaogimage = APP_URL.'/assets/images/og.jpg';
$metarobots = 'index,follow';