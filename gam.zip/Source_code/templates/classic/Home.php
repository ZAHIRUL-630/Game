<main class="container bg-light shadow-sm rounded-bottom border-top">
    <h1 class="visually-hidden"><?php echo APP_NAME; ?> Watch Movie Online and Download Free</h1>
    <h2 class="visually-hidden"><?php echo APP_NAME; ?></h2>
    <?php include(getAds($AdsPath . '/home_top')); ?>
    <div class="row">
        <!-- Start Main Container -->
        <div class="col-12 col-lg-8">
            <h3><i class="fa fa-tint" aria-hidden="true"></i> Trending Movies</h3>
            <div class="row row-cols-3 row-cols-sm-4 row-cols-md-6 bg-light g-1 g-sm-2">
                <?php
                $files = $trendmovies;
                require __DIR__ . '/_files_list.php';
                unset($trendmovies);
                ?>
            </div>
            <div class="text-center mt-2"><a href="<?php echo APP_URL . '/movies/1/trending'; ?>" class="btn btn-outline-primary text-uppercase">See All <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>
                </a></div>
            <h3><i class="fa fa-bandcamp" aria-hidden="true"></i> Latest Movies</h3>

            <div class="row row-cols-3 row-cols-sm-4 row-cols-md-6 bg-light g-1 g-sm-2">
                <?php
                $files = $newmovies;
                require __DIR__ . '/_files_list.php';
                unset($newmovies);
                ?>
            </div>
            <div class="text-center m-2"><a href="<?php echo APP_URL . '/movies/1/latest-movies'; ?>" class="btn btn-outline-primary text-uppercase">See All <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>
                </a></div>

        </div>
        <!-- End Main Container -->
        <!-- Start Sidebar -->
        <div class="col-12 col-lg-4">

            <h3><i class="fa fa-bolt" aria-hidden="true"></i> Most Viewed Movies <span class="float-end d-none d-sm-block"><a href="<?php echo APP_URL . '/movies/1/most-viewed'; ?>" class="btn btn-outline-primary btn-xs">See All <i class="fa fa-plus-circle" aria-hidden="true"></i>
                    </a></span></h3>

            <ul class="list-group sb-list">
                <?php
                $listitems = $mostviewed;
                include __DIR__ . '/_list_item.php'; ?>
            </ul>
        </div>
        <!-- End Sidebar -->

        <div class="col-md-4">

            <h3><i class="fa fa-film" aria-hidden="true"></i> Movie Genres <span class="float-end d-none d-sm-block"><a href="<?php echo APP_URL . '/genres/1/a-to-z' . $endRoute; ?>" class="btn btn-outline-primary btn-xs">See All <i class="fa fa-plus-circle" aria-hidden="true"></i>
                    </a></span></h3>
            <ul class="row row-cols-2 g-1 list-inline sb-cols">
                <?php foreach ($genres as $genre)
                    echo '<li class="col">
                    <a data-bs-toggle="tooltip" title="' . $genre['name'] . '" href="' . APP_URL . '/genre/' . $genre['slug'] . '" class="list-group-item"><i class="fa fa-caret-right" aria-hidden="true"></i> ' . $genre['name'] . '</a>
                </li>';
                ?>
            </ul>
        </div>
        <div class="col-md-4">
            <h3><i class="fa fa-users" aria-hidden="true"></i> Movie by Stars <span class="float-end d-none d-sm-block"><a href="<?php echo APP_URL . '/stars/1/a-to-z' . $endRoute; ?>" class="btn btn-outline-primary btn-xs">See All <i class="fa fa-plus-circle" aria-hidden="true"></i>
                    </a></span></h3>
            <ul class="row row-cols-2 g-1 list-inline sb-cols">
                <?php foreach ($stars as $star)
                    echo '<li class="col">
                    <a data-bs-toggle="tooltip" title="' . $star['name'] . '" href="' . APP_URL . '/star/' . $star['slug'] . '" class="list-group-item"><i class="fa fa-caret-right" aria-hidden="true"></i> ' . $star['name'] . '</a>
                </li>';
                ?>
            </ul>
        </div>
        <div class="col-md-4">
            <h3><i class="fa fa-users" aria-hidden="true"></i> Movie by Directors <span class="float-end d-none d-sm-block"><a href="<?php echo APP_URL . '/directors/1/a-to-zsharemovie' . $endRoute; ?>" class="btn btn-outline-primary btn-xs">See All <i class="fa fa-plus-circle" aria-hidden="true"></i>
                    </a></span></h3>
            <ul class="row row-cols-2 g-1 list-inline sb-cols">
                <?php foreach ($directors as $director)
                    echo '<li class="col">
                    <a data-bs-toggle="tooltip" title="' . $director['name'] . '" href="' . APP_URL . '/director/' . $director['slug'] . '" class="list-group-item"><i class="fa fa-caret-right" aria-hidden="true"></i> ' . $director['name'] . '</a>
                </li>';
                ?>
            </ul>
        </div>
    </div>
    <?php include(getAds($AdsPath . '/home_bottom')); ?>
</main>