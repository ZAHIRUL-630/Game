document.addEventListener("DOMContentLoaded", function () {
    const updateStatus = document.getElementById("update-status");
    const updateLog = document.getElementById("update-log");
    const statusBarFill = document.getElementById("status-bar-fill");
    const updateBtn = document.getElementById("update-btn");
    const currentVersionElement = document.getElementById("current-version");
    const headerVersionElement = document.querySelector(".header-version");
    const versionHistoryContainer = document.querySelector(".version-history");
    let clientVersion = "";
    let clientVersions = [];
    let ellipsisInterval;
    function updateStatusBar(color) {
        statusBarFill.style.width = "100%";
        statusBarFill.style.background = color;
    }
    if (!updateStatus || !updateLog || !statusBarFill || !updateBtn || !currentVersionElement || !versionHistoryContainer) {
        return; 
    }
    function startIncrementalEllipsis(element) {
        let ellipsisState = 0;
        const baseText = element.textContent.replace(/\.+$/, "");
        ellipsisInterval = setInterval(() => {
            ellipsisState = (ellipsisState + 1) % 4;
            const ellipsis = ".".repeat(ellipsisState);
            element.textContent = baseText + ellipsis;
        }, 500);
    }
    function stopIncrementalEllipsis() {
        if (ellipsisInterval) {
            clearInterval(ellipsisInterval);
            ellipsisInterval = null;
        }
    }
    function rot13(str) {
        return str.replace(/[a-zA-Z]/g, function (char) {
            let base = char <= "Z" ? 65 : 97;
            return String.fromCharCode(((char.charCodeAt(0) - base + 13) % 26) + base);
        });
    }
    fetch("../../../config/version")
        .then(response => {
            if (!response.ok) {
                throw new Error("Failed to fetch client-side version file.");
            }
            return response.text();
        })
        .then(text => {
            if (!text) {
                throw new Error("Client version file is empty!");
            }
            clientVersions = text.split("\n").map(line => {
                let [version, date, changelog] = line.split("|").map(e => e.trim());
                return { version, date, changelog };
            }).filter(v => v.version);
            if (clientVersions.length > 0) {
                clientVersion = clientVersions[0].version;
                currentVersionElement.textContent = `Version ${clientVersion}`;
                if (headerVersionElement) {
                    headerVersionElement.textContent = `V ${clientVersion}`;
                }
            }
            versionHistoryContainer.innerHTML = `<h2>Version History</h2>`;
            clientVersions.forEach(({ version, date, changelog }) => {
                const versionItem = document.createElement("div");
                versionItem.classList.add("version-item");
                versionItem.innerHTML = `
                    <h3>Version ${version} ${version === clientVersion ? "(Your Current Version)" : ""}</h3>
                    <p class="date">Released: ${date || "Unknown Date"}</p>
                    <p>${changelog || "No changelog available."}</p>
                `;
                versionHistoryContainer.appendChild(versionItem);
            });
            let enc_url = rot13("uggcf://vzqribcf.va/ncv/hcqngrf/trgIrefvba.cuc?cvq=1");
            return fetch(enc_url);
        })
        .then(response => {
            if (!response.ok) {
                throw new Error("Failed to fetch server version.");
            }
            return response.json();
        })
        .then(data => {
            if (!data.success || !data.latest_version) {
                throw new Error("Server returned an error or missing latest version.");
            }

            const latestVersion = data.latest_version.version ? data.latest_version.version.trim() : null;
            const changelog = data.latest_version.changelog ? data.latest_version.changelog.trim() : "No changelog available.";

            if (!latestVersion) {
                throw new Error("Latest version is undefined!");
            }

            if (clientVersion !== latestVersion) {
                updateStatus.textContent = `New version available: ${latestVersion}`;
                updateLog.value = `🔄 Update Found!\nVersion: ${latestVersion}\n\n📝 Changelog:\n${changelog}`;
                updateBtn.disabled = false;
                updateStatusBar("#27ae60");
            } else {
                updateStatus.textContent = "✅ Your CMS is running the latest version.";
                updateLog.value = "✅ Your CMS is running the latest version.";
                updateStatusBar("#3498db");
            }
        })
        .catch(error => {
            console.error("Fetch Error:", error);
            updateStatus.textContent = "❌ Error fetching version!";
            updateLog.value = `⚠️ ${error.message}\n\nPlease contact support:\n📧 devt.santu@gmail.com`;
            updateStatusBar("#e74c3c");
        });
    updateBtn.addEventListener("click", function () {
        if (!confirm("⚠️ Are you sure you want to update your CMS?")) return;

        updateBtn.disabled = true;
        updateStatus.textContent = "🔄 Updating CMS";
        updateLog.value = "⏳ Preparing update...\n";
        startIncrementalEllipsis(updateStatus);

        const eventSource = new EventSource("updateProcess.php");

        eventSource.onmessage = function (event) {
            const data = JSON.parse(event.data);
            if (data.message === "end") {
                eventSource.close();
                stopIncrementalEllipsis();
                updateStatus.textContent = `🎉 Updated.`;
                updateStatusBar("#27ae60");
                setTimeout(() => {
                    location.reload(true);
                }, 3000);
                return;
            }
            updateLog.value += data.message + "\n";
            updateLog.scrollTop = updateLog.scrollHeight;
        };

        eventSource.onerror = function () {
            stopIncrementalEllipsis();
            updateLog.value += "❌ Update process failed!\n";
            eventSource.close();
            updateStatus.textContent = "❌ Update failed!";
            updateStatusBar("#e74c3c");
            updateBtn.disabled = false;
        };

        eventSource.onopen = function () {
            updateLog.value += "✅ Connected to update server...\n";
        };
    });
});